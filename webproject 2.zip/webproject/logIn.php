<!DOCTYPE html>
<?php
    session_start();
    // Check if the user has already logged in
    if(isset($_SESSION['Email']))
    {
        // header() is used to send a raw HTTP header. It must be called before any actual output is sent.
        header("Location: ladingP.php");
      }

    else if(isset($_SESSION['EmailB']))
    {
        header("Location: babys.php");
    }
?>

<html >
  <head>
    <meta charset="utf-8">
    <title>Awn Login</title>

      <link rel="stylesheet" href="login.css">
      <link rel="stylesheet" href="nav.css">
      <link rel="icon" href="icon.png" >



  </head>
  <body>

    <section class="cont">
      <nav>
        <a href="web.php"> <h2>AWN</h2> </a>
            <ul class="nav">
          <li><a href="web.php#home">Home</a></li>
          <li><a href="web.php#aboutus">About us</a></li>
          <li><a href="web.php#ser">Servises</a></li>
          <li><a href="web.php#fot">Contact</a>
          </li>

          <!--<li><a  class="user" href="#">
              <img src="logout.png" >
              </a>

              <div class="dropdown">
                  <button class="dropbtn"><img src="profile.png"></button>
                  <div class="dropdown-content">
                    <a href="#">Link 1</a>
                    <a href="#">Link 2</a>
                    <a href="#">Link 3</a>
                  </div>
                </div>


              </button>
              </a>
         </li>
        </ul>
      </nav>
    -->
    </section>

  <!---------------Log in--------------------->


  <section>
  <div class="center">
      <h1>Log in</h1>
      <h2>welcome back!</h2>

      <?php include('LoginC.php'); ?>

      <form method="post" action="logIn.php">
        <?php if(isset($errorL)){
          if(! empty($errorL)){
            foreach ($errorL as $errorL) { ?>
              <script>
              document.getElementById('center111').style.height = '1200px';

              </script>
              <p id="error" style="color:red;" > <?php echo "*".$errorL; ?> </p>

            <?php }
          }
        } ?>
        <div class="txt_field">
          <input type="text" name="email" required >
          <span></span>
          <label>ُEmail </label>
        </div>

        <div class="txt_field">
          <input type="password"name="password" required >
          <span></span>
          <label>Password</label>
        </div>

        <div class="pass"> <a href="forgetPass.php" style="color: rgb(192, 192, 192);" > Forgot Password? </a></div>
        <br>
        <input type="submit" value="Login" name="submitt">
        <div class="signup_link">
          Don't have an account?
          <br>
          <display="inline">


          <a href="SignUpP.php">Sign up as parent </a>
          <br>
          <a href="signupB1.php">Sign up as babyasitter </a>
          </display>
        </div>
      </form>
</div>
</section>









  </body>
</html>
