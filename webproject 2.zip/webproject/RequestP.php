<?php
session_start();
if(!isset($_SESSION['Email'])){
  header("Location: web.php");
}
ini_set('display_errors',1); 
error_reporting(E_ALL);

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");
if (!$conn = mysqli_connect(host,Username,Password))
    die("Connection failed.");


    if(!mysqli_select_db($conn, db))
        die("Could not open the ".db." database.");

$Kidsname = $_POST['Itemname'];
$numberOfKids = $_POST['number'];
$Duration = $_POST['Duration'];
$date = $_POST['Date'];
$date= date("Y-m-d", strtotime($date));
$age = $_POST['age'];
$service_name = $_POST['category'];
$parent_email=$_SESSION['Email'];

//$query = "INSERT INTO requests VALUES ('$parent_email',null, '$numberOfKids', '$date', '$Duration', '$service_name')";
$query = "INSERT INTO request (`num_of_kids`, `reqdate`, `reqstatus`, `typeofsecvice`, `kidname`, `age`, `parent_email`, `duration`) VALUES ('$numberOfKids', '$date', 'pending', '$service_name', '$Kidsname','$age','$parent_email','$Duration')";
//INSERT INTO `request`(`num_of_kids`, `reqdate`, `reqstatus`, `typeofsecvice`, `kidname`, `age`, `parent_email`, `duration`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]','[value-8]','[value-9]')
$result = mysqli_query($conn,$query);


  header("Location:/parentaRequest.php");



$conn -> close();
?>
