<?php
session_start();
ini_set ('display_errors' ,1);
error_reporting(E_ALL);

Define("host", "localhost");
Define ("Username","root");
Define("Password","");
Define("db", "AWN'S") ;

$fname="";
$lname="";
$email="";
$Password="";
$city="";
$profile_photo="";


//create connection 
$connection = mysqli_connect(host,Username,Password,db);
//cheak connection
if (!$connection) {
  print ("<p>could not connect to •database</p>");
   die("could not connect to the-db-</html>");
  }
  $query="SELECT * FROM  babysitter";
  $result= mysqli_query($connection,$query);
  
  if ($result){
      echo"yaaay";
  }
  else{
      echo"naay";
  }
  



if(!$connection)
die();

if(isset($_POST['delete'])){
$email = $_SESSION['email'];
$query = "DELETE FROM parent WHERE Email = '$email';";
mysqli_query($connection, $query);
mysqli_close($connection);
unset($_SESSION['email']);
session_destroy();
}
 //edit 
 if(isset($_POST['update'])){
 
  $password =$_POST['password'];
  $id =$_POST['id'];
  $gender =$_POST['gender'];
  $age =$_POST['age'];
  $phone_number =$_POST['phone_number'];
  $city =$_POST['city'];
  $bio =$_POST['bio'];
  $profile_photo =$_POST['profile_photo'];
  $firstname =$_POST['firstname'];
  $lastname =$_POST['lastname'];
  $email = $_SESSION['email'];
  $select= "SELECT * FROM `parent` WHERE Email ='$email'";
  $sql =  mysqli_query($connection, $query);
  $row = mysqli_fetch_assoc($sql);


  $res= $row['Email'];
    if($res === $email)
    {

      $update = "update users set password ='$password ,id='$id',gender=' $gender', age='$age', phone_number=' $phone_number',city=' $city',bio='$bio ',profile_photo=' $profile_photo',firstname=' $firstname', lastname=' $lastname',
      WHERE email='$email' ";
      
     
if($sql2)
       { 
           /*Successful*/
           header('location:Dashboard.php');
       }
       else
       {
           /*sorry your profile is not update*/
           header('location:Profile_edit_form.php');
       }
      }
    else{
        /*sorry your id is not match*/
        header('location:Profile_edit_form.php');
    }
   
}
?>


<!DOCTYPE html>
<html >
  <head>
    <meta charset="utf-8">
    <title>Register Form</title>
    <link rel="stylesheet" href="login2.css">
    <link rel="icon" href="icon.png" >
    <script src="JS/Validations.js"></script>
  </head>
  <body>



    <section class="cont">
      <nav>
       <a href="web.html"> <h2>AWN</h2> </a>
        <ul class="nav">
          <li><a href="#">Home</a></li>
          <li><a href="#">About us</a></li>
          <li><a href="#">Servises</a></li>
          <li><a href="#">Contact</a>
          </li>

         </li>
        </ul>
      </nav>
    </section>
    <!-------------------Register------------->


    <div class="center111"> 
   
    <h2> Edit My Profile </h2>
      <form method="post">
        

       <div id="addinPic" class="d-flex flex-column align-self-center mt-4">
        <img id="profile-image" src="imagess/undraw_profile_pic_ic.png" alt=" picture">
        <input type="file" id="uploadFile" name="profile-img">
        <label class="align-self-end" for="uploadFile"><i class="bi bi-plus-circle-fill" id="plusS"></i></label>
        <div class="col-9">
         <div class="customUpload btnUpload btnM">
         <input id="file" type="file" onchange="loadFile(event)"/>
         </div>
       </div>
     </div>

    
<!--Name-->
<div class="txt_field"> 
  <label for="firstname"> First Name  </label> 
  <br> <br>
   <input name ="First_Name" type="text"  value=" <?php echo $Fname; ?> " required id="fname">
   </div> 
        
       
   
       
<!--Last Name-->
        <div class="txt_field"> 
           <label for="lastname"> Last Name </label> <br> <br>
            <input name ="Last_Name" type="text" class="bg-light form-control" placeholder = "Last name" value=" <?php echo $lname;?> " required id="lname"> 
          </div>
         
        
<!--Email-->
        <div class="txt_field"> 
          <label>Email</label> 
          <br> <br> <input name ="Email" type="text"  value=" <?php echo $email;?>" required id="Email"> 
        </div> 
        
  <!--New Pass -->
        <div class="txt_field"> 
          <label> Create a New Password</label> <br> <br>
           <input name ="Password" type="text"  value=" <?php echo $Password;?>" required id="Password">
           </div> 
  
      
        <div class="txt-field"> 
        <div class="mb-3">
        <select class="form-select" required aria-label="select example">
          <option value=<?php echo $city;?>>City </option>
            <option> Riyadh </option>
            <option> Jeddah</option>
            <option> Makkah </option>
            <option> Dammam</option>
            <option> Madinah </option>
          
          </select>
          </div>  
        
        </div>
      
        

<div class="txt_field">
  <input type="Address"  id="Address" name="Address" required>
  <label>Address</label>
  <span></span>
</div>                
 


  
<!---
<button class="profile-card__button button--orange">Delete account </button>
<button class="profile-card__button button--blue js-message-btn">  <a href = "ediit.html" target="_blank"> Edit Profile  </a></button>
-->       
     
  <div class="profile-card-ctr">

    <button class="profile-card__button button--orange" name ="save" id="saveBtn">Save Changes</button>  
    <button class="profile-card__button button--orange" name ="update" onclick="confirmdelete( 'Yes or No'  )"> Delete account </button>
    <script>
      function confirmdelete(x){
        var result = confirm(" Do you want to delete this account? ")
      }
      
      
      
      
      </script>
  </div> 
















    <script>  

    var emailExists = sessionStorage.getItem('email_exists');
      var thereIsError = false;
      if(emailExists == 1)
        document.getElementById('error_alert').innerHTML += '&#9679; Email Exists!<br>';
    
      if(!validEmail($('#Email').val())){
        document.getElementById('error_alert').innerHTML += '&#9679; Invalid Email Address!<br>'; 
        thereIsError = true;
      }
      if(!validPass($('#Password').val())){
        document.getElementById('error_alert').innerHTML += '&#9679; Password should be at least 8 characters and should contain at least one special character<br>'; 
        thereIsError = true;
      }
      if(!validFirstName($('#fname').val())){
        document.getElementById('error_alert').innerHTML += '&#9679; First name should be maximum 30, and should not contain special characters or digits<br>'; 
        thereIsError = true;
      }
      if(!validLastName($('#lname').val())){
        document.getElementById('error_alert').innerHTML += '&#9679; Last name should be at least 1 letters and maximum 30, and should not contain special characters or digits<br>'; 
        thereIsError = true;
      }

      if(!validAddress($('#Address').val())){
        document.getElementById('error_alert').innerHTML += '&#9679; Address should be maximum 30, and should not contain special characters or digits<br>'; 
        thereIsError = true;
      }
    
      if((emailExists == 1) ||(thereIsError === true)){
         e.preventDefault();
         $('#sign_up_form').attr('target','my_iframe')
         $('#error_alert').css('display', 'block');
      }
      else{
         $('#success_alert').html('Service Added Successfully');
         $('#success_alert').css('display', 'block');
      }
         

  
  </script>
  </body>
</html>


