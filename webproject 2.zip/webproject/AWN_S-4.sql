-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 08, 2022 at 05:26 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `AWN'S`
--

-- --------------------------------------------------------

--
-- Table structure for table `babysitter`
--

CREATE TABLE `babysitter` (
  `password` varchar(30) CHARACTER SET latin1 NOT NULL,
  `id` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `gender` varchar(7) CHARACTER SET latin1 DEFAULT NULL,
  `age` int(100) DEFAULT NULL,
  `email` varchar(100) CHARACTER SET latin1 NOT NULL,
  `phone_number` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `city` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `bio` text CHARACTER SET latin1 DEFAULT NULL,
  `profile_photo` blob DEFAULT NULL,
  `firstname` varchar(10) CHARACTER SET latin1 NOT NULL,
  `lastname` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `babysitter`
--

INSERT INTO `babysitter` (`password`, `id`, `gender`, `age`, `email`, `phone_number`, `city`, `bio`, `profile_photo`, `firstname`, `lastname`) VALUES
('rr23', '442201364', 'male', 22, 'joey@gmail.com', '0500040575', 'NewYork', 'how you doin\'?', 0x69636f6e2e706e67, 'joey', 'Tribbiani');

-- --------------------------------------------------------

--
-- Table structure for table `bookingandjobs`
--

CREATE TABLE `bookingandjobs` (
  `id` int(11) NOT NULL,
  `reuest_id` int(100) UNSIGNED DEFAULT NULL,
  `parent_email` varchar(25) CHARACTER SET latin1 NOT NULL,
  `babysitter_email` varchar(30) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookingandjobs`
--

INSERT INTO `bookingandjobs` (`id`, `reuest_id`, `parent_email`, `babysitter_email`) VALUES
(1, 7, 'halah@gmail.com', 'joey@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `booking_and_jobs`
--

CREATE TABLE `booking_and_jobs` (
  `id` int(11) UNSIGNED NOT NULL,
  `statusjob` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `request_id` int(100) UNSIGNED DEFAULT NULL,
  `parent_email` varchar(25) CHARACTER SET latin1 NOT NULL,
  `babysitter_email` varchar(30) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `kids`
--

CREATE TABLE `kids` (
  `kid_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `age` int(100) DEFAULT NULL,
  `type_of_service` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `duration` int(10) UNSIGNED DEFAULT NULL,
  `request_id` int(100) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `offer_id` int(11) NOT NULL,
  `price` double UNSIGNED DEFAULT NULL,
  `parent_email` varchar(25) CHARACTER SET latin1 NOT NULL,
  `babysitter_email` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `request_id` int(30) UNSIGNED DEFAULT NULL,
  `offerstatus` varchar(30) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `parent`
--

CREATE TABLE `parent` (
  `password` int(30) NOT NULL,
  `firstname` varchar(30) CHARACTER SET latin1 NOT NULL,
  `city` varchar(20) CHARACTER SET latin1 NOT NULL,
  `location` varchar(30) NOT NULL,
  `profile_photo` blob DEFAULT NULL,
  `lastname` varchar(13) CHARACTER SET latin1 NOT NULL,
  `email` varchar(25) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parent`
--

INSERT INTO `parent` (`password`, `firstname`, `city`, `location`, `profile_photo`, `lastname`, `email`) VALUES
(33, 'halah', 'riyadh', 'Alhamra', 0x69636f6e2e706e67, 'Aldekhiel', 'halah@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `request_id` int(100) UNSIGNED NOT NULL,
  `num_of_kids` int(10) UNSIGNED DEFAULT NULL,
  `reqdate` date DEFAULT NULL,
  `reqstatus` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `typeofsecvice` varchar(30) CHARACTER SET latin1 NOT NULL,
  `kidname` varchar(10) CHARACTER SET latin1 NOT NULL,
  `age` int(10) NOT NULL,
  `parent_email` varchar(25) CHARACTER SET latin1 NOT NULL,
  `duration` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`request_id`, `num_of_kids`, `reqdate`, `reqstatus`, `typeofsecvice`, `kidname`, `age`, `parent_email`, `duration`) VALUES
(3, 1, '2022-11-01', 'accepted', 'prepare meals', 'sultan', 5, 'halah@gmail.com', 15),
(7, 1, '2022-11-03', 'accepted', 'infant babysitting', 'salman', 1, 'halah@gmail.com', 1),
(14, 1, '2022-11-03', 'pending', 'infant babysitting', 'salman', 1, 'halah@gmail.com', 1),
(17, 1, '2022-11-03', 'pending', 'infant babysitting', 'salman', 1, 'halah@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `review_and_rate`
--

CREATE TABLE `review_and_rate` (
  `id` int(30) NOT NULL,
  `rate` int(20) UNSIGNED DEFAULT NULL,
  `review` text CHARACTER SET latin1 DEFAULT NULL,
  `babysitter_email` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `username` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `review_and_rate`
--

INSERT INTO `review_and_rate` (`id`, `rate`, `review`, `babysitter_email`, `username`) VALUES
(1, 0, 'very good', 'joey@gmail.com', 'halah'),
(2, 3, 'yees', 'joey@gmail.com', 'rr'),
(3, 3, 'good', 'joey@gmail.com', 'hh'),
(4, 2, 'rrr', 'joey@gmail.com', 'halah');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `babysitter`
--
ALTER TABLE `babysitter`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `bookingandjobs`
--
ALTER TABLE `bookingandjobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `babysitter_email` (`babysitter_email`),
  ADD KEY `parent_email` (`parent_email`),
  ADD KEY `reuest_id` (`reuest_id`);

--
-- Indexes for table `booking_and_jobs`
--
ALTER TABLE `booking_and_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_id` (`request_id`);

--
-- Indexes for table `kids`
--
ALTER TABLE `kids`
  ADD PRIMARY KEY (`kid_id`),
  ADD KEY `request_id` (`request_id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`offer_id`),
  ADD KEY `babysitter_username` (`babysitter_email`),
  ADD KEY `parent_username` (`parent_email`),
  ADD KEY `request_id` (`request_id`);

--
-- Indexes for table `parent`
--
ALTER TABLE `parent`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `review_and_rate`
--
ALTER TABLE `review_and_rate`
  ADD PRIMARY KEY (`id`),
  ADD KEY `babysitter_username` (`babysitter_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookingandjobs`
--
ALTER TABLE `bookingandjobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `booking_and_jobs`
--
ALTER TABLE `booking_and_jobs`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `kids`
--
ALTER TABLE `kids`
  MODIFY `kid_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `offer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `request_id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `review_and_rate`
--
ALTER TABLE `review_and_rate`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookingandjobs`
--
ALTER TABLE `bookingandjobs`
  ADD CONSTRAINT `bookingandjobs_ibfk_1` FOREIGN KEY (`babysitter_email`) REFERENCES `babysitter` (`email`),
  ADD CONSTRAINT `bookingandjobs_ibfk_2` FOREIGN KEY (`parent_email`) REFERENCES `parent` (`email`),
  ADD CONSTRAINT `bookingandjobs_ibfk_3` FOREIGN KEY (`reuest_id`) REFERENCES `request` (`request_id`);

--
-- Constraints for table `booking_and_jobs`
--
ALTER TABLE `booking_and_jobs`
  ADD CONSTRAINT `booking_and_jobs_ibfk_3` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`);

--
-- Constraints for table `kids`
--
ALTER TABLE `kids`
  ADD CONSTRAINT `kids_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`);

--
-- Constraints for table `offers`
--
ALTER TABLE `offers`
  ADD CONSTRAINT `offers_ibfk_1` FOREIGN KEY (`babysitter_email`) REFERENCES `babysitter` (`email`),
  ADD CONSTRAINT `offers_ibfk_3` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`),
  ADD CONSTRAINT `offers_ibfk_4` FOREIGN KEY (`parent_email`) REFERENCES `parent` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
