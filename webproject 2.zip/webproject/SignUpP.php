<!DOCTYPE html>
<?php
    session_start();
    // Check if the user has already logged in
    if(isset($_SESSION['Email']))
        // header() is used to send a raw HTTP header. It must be called before any actual output is sent.
        header("Location: ladingP.php");

        ?>


<html>
  <head>
    <meta charset="utf-8">
    <title>Register Form</title>
    <link rel="stylesheet" href="login.css">
    <link rel="icon" href="icon.png" >
    <!--<script defer src="./Validations.js"></script>-->
  </head>
  <body>


    <section class="cont">
      <nav>
       <a href="web.php"> <h2>AWN</h2> </a>
        <ul class="nav">
          <li><a href="#">Home</a></li>
          <li><a href="#">About us</a></li>
          <li><a href="#">Servises</a></li>
          <li><a href="#">Contact</a>
          </li>

         </li>
        </ul>
      </nav>
    </section>
    <!-------------------Register------------->


    <div class="center111">
    <h1>Sign up</h1>
    <h2> Enter your details to continue </h2>
   <div id="addinPic" class="d-flex flex-column align-self-center mt-4">
        <img id="profile-image" src="images/undraw_profile_pic_ic.png" alt="pet picture">
        <input type="file" id="uploadFile" name="profile-img">
        <label class="align-self-end" for="uploadFile"><i class="bi bi-plus-circle-fill" id="plusS"></i></label>
        <div class="col-9">
         <div class="customUpload btnUpload btnM">
         <input id="file" type="file" onchange="readURL(this)" accept="Image/*" name="img">
         </div>
       </div>
     </div>
<?php include('SignupP1.php'); ?>
    <div id="error"></div>
      <form id="form" action="signUpP.php" method="post">
        <?php if(isset($errors)){
          if(! empty($errors)){
            foreach ($errors as $errors) { ?>
              <script>
              document.getElementById('center111').style.height = '1200px';

              </script>
              <p id="error" style="color:Red;" > <?php echo "*".$errors; ?> </p>

            <?php }
          }
        } ?>
        <div class="txt_field">
          <input type="fname"  id="fname" name="name" required>
          <label>*First name</label>
          <span></span>
          <div class="error"></div>
        </div>

        <div class="txt_field">
          <input type="lname"  id="lname" name="lastname" required>
          <label>*Last name</label>
          <span></span>
          <div class="error"></div>

        </div>

        <div class="txt_field">
          <input type="Email"  id="Email" name="Email" required>
          <label>*Email</label>
          <span></span>
          <div class="error"></div>
        </div>

      <p>
          <div class="txt_field">
            <input type="Password"  id="Password" name="Password" required>
            <label>*Create your Password</label>
            <span></span>

          </div>

     <div class="txt_field">
            <input type="Password"  id="Password2" name="Password2" required>
             <label>*Comfirm your Password</label>

            <span></span>

          </div>
        </p>

          <div class="txt-field">
          <div class="mb-3">
            <select class="form-select" required aria-label="select example" name="city"   required>
              <option   value="">*City</option>
          <option > Riyadh </option>
          <option > Jeddah</option>
          <option > Makkah </option>
          <option > Dammam </option>
          <option > Madinah </option>

            </select>
          </div>
</div>


        <div class="txt_field">
          <input type="Address"  id="Address" name="Address" required>
          <label>*Address</label>

            <div id="validationServer03Feedback" class="invalid-feedback">



          <span></span>
        </div>

     </div>


          <div class="col-12">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
              <label class="form-check-label" for="invalidCheck">
                I agree with terms and privacy policy
              </label>
        <input type="submit" value="Sign Up" name="submit">
        <div class="signup_link">
          Have an account ? <a href="logIn.html">Login here</a>
       </div>
       <br>
       <br>

      </form>
    </div>
    <script>
function validPass(Password){
    var eight = true;
    var specialChar = false;
    if(Password.length < 8)
      valid = false;
    var sc = '!”#$%&’()*+,-./:;<=>?@[\]^_{|}~`';
    for(var i = 0; i < sc.length; i++){
      if(Password.includes(sc[i],0)){
        specialChar = true;
        break;
      }
    }
    return eight === true && specialChar === true;
}
function isValidFirstname(fname) {
    if (
        typeof fname !== "string" ||
        /[0-9]+/g.test(fname)
    ) {
        return false;
    }
    return true;
}

function isValidlastname(lname) {
    if (
        typeof fname !== "string" ||
        /[0-9]+/g.test(lname)
    ) {
        return false;
    }
    return true;
}

    var emailExists = sessionStorage.getItem('email_exists');
      var thereIsError = false;
      if(emailExists == 1)
        document.getElementById('error_alert').innerHTML += '&#9679; Email Exists!<br>';

      if(!validEmail($('#Email').val())){
        document.getElementById('error_alert').innerHTML += '&#9679; Invalid Email Address!<br>';
        thereIsError = true;
      }

      function validPass(Password){
    var eight = true;
    var specialChar = false;
    if(Password.length < 8)
      valid = false;
    var sc = '!”#$%&’()*+,-./:;<=>?@[\]^_{|}~`';
    for(var i = 0; i < sc.length; i++){
      if(Password.includes(sc[i],0)){
        specialChar = true;
        break;
      }
    }
  }
</script>
</body>
</html>
