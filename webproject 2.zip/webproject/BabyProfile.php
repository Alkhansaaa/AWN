<!DOCTYPE html>
<!--PHP-->
<?php
ini_set('display_errors',1); 
error_reporting(E_ALL);
 

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");


$connection = mysqli_connect(host,Username,Password,db);
if(!$connection){
  print("<p>could not connect to database</p>");
  die("could not connect to the db </html>");

}

$query="SELECT * FROM review_and_rate"; 

$result=mysqli_query($connection,$query);



?>

<!--HTML-->
<html lang="en" >
<head>
<meta charset="UTF-8">
<title>Profile Card</title>
<meta name="viewport"
content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="style2.css">
<link rel="icon" href="icon.png" >

</head>
<body>

<!--Header-->
<section class="cont">
<nav>
<a href="babys.php"> <h2>AWN</h2> </a>
<ul class="nav">
<li><a href="babys.php">Home</a></li>
<li><a href="babys.php#about">About us</a></li>
<li><a href="babys.php#ser">Servises</a></li>
<li><a href="babys.php#foot">Contact</a>
</li>
<li><a  class="user" href="web.php">
<img src="logout.png" >
</a>

  <div class="dropdown">
  <button class="dropbtn"><img src="profile.png"></button>
  <div class="dropdown-content">
  <a href="BabyProfile.php">Edit profile</a>
  <a href="jobs.php">jobs</a>
  <a href="offerslistBS.php">My Offers</a>
  </div>
  </div>
          
</button>
</a>
</li>
</ul>
</nav>
</section>
<!--class-->
<form action="BabyEdit.php" method="post">
<div class="wrapper">
<div class="profile-card js-profile-card">
<div class="profile-card__img">
<img src= "undraw_profile_pic_ic.png" alt="profile card">
</div>
<div class="profile-card__cnt js-profile-cnt">
<div class="profile-card__name"> Monica Geller </div>
<div class="profile-card__txt"> Bio </div>
<div class="profile-card-loc">
<span class="profile-card-loc__icon">
<svg class="icon"><use xlink:href="#icon-location"></use></svg>
</span>
<span class="profile-card-loc__txt">
   Riyadh, Saudi Arabia
</span>
        
</div>
  
</div>
<!-- Buttons -->
<div class="profile-card-ctr">
<button class="profile-card__button button--blue js-message-btn">  <a href = "BabyEdit.php" target="_blank"> Edit Profile  </a></button>
<!--Delete Buttons-->
<button class="profile-card__button button--orange" onclick="confirmdelete( 'Yes or No'  )"><a href = "BabyEdit.php" target="_blank"> Delete account </a></button>       
</div>
</div>

<svg hidden="hidden">
<defs>
<!--Location-->
<symbol id="icon-location" viewBox="0 0 32 32">
 <title>location</title>
<path d="M16 31.68c-0.352 0-0.672-0.064-1.024-0.16-0.8-0.256-1.44-0.832-1.824-1.6l-6.784-13.632c-1.664-3.36-1.568-7.328 0.32-10.592 1.856-3.2 4.992-5.152 8.608-5.376h1.376c3.648 0.224 6.752 2.176 8.608 5.376 1.888 3.264 2.016 7.232 0.352 10.592l-6.816 13.664c-0.288 0.608-0.8 1.12-1.408 1.408-0.448 0.224-0.928 0.32-1.408 0.32zM15.392 2.368c-2.88 0.192-5.408 1.76-6.912 4.352-1.536 2.688-1.632 5.92-0.288 8.672l6.816 13.632c0.128 0.256 0.352 0.448 0.64 0.544s0.576 0.064 0.832-0.064c0.224-0.096 0.384-0.288 0.48-0.48l6.816-13.664c1.376-2.752 1.248-5.984-0.288-8.672-1.472-2.56-4-4.128-6.88-4.32h-1.216zM16 17.888c-3.264 0-5.92-2.656-5.92-5.92 0-3.232 2.656-5.888 5.92-5.888s5.92 2.656 5.92 5.92c0 3.264-2.656 5.888-5.92 5.888zM16 8.128c-2.144 0-3.872 1.728-3.872 3.872s1.728 3.872 3.872 3.872 3.872-1.728 3.872-3.872c0-2.144-1.76-3.872-3.872-3.872z"></path>
<path d="M16 32c-0.384 0-0.736-0.064-1.12-0.192-0.864-0.288-1.568-0.928-1.984-1.728l-6.784-13.664c-1.728-3.456-1.6-7.52 0.352-10.912 1.888-3.264 5.088-5.28 8.832-5.504h1.376c3.744 0.224 6.976 2.24 8.864 5.536 1.952 3.36 2.080 7.424 0.352 10.912l-6.784 13.632c-0.32 0.672-0.896 1.216-1.568 1.568-0.48 0.224-0.992 0.352-1.536 0.352zM15.36 0.64h-0.064c-3.488 0.224-6.56 2.112-8.32 5.216-1.824 3.168-1.952 7.040-0.32 10.304l6.816 13.632c0.32 0.672 0.928 1.184 1.632 1.44s1.472 0.192 2.176-0.16c0.544-0.288 1.024-0.736 1.28-1.28l6.816-13.632c1.632-3.264 1.504-7.136-0.32-10.304-1.824-3.104-4.864-5.024-8.384-5.216h-1.312zM16 29.952c-0.16 0-0.32-0.032-0.448-0.064-0.352-0.128-0.64-0.384-0.8-0.704l-6.816-13.664c-1.408-2.848-1.312-6.176 0.288-8.96 1.536-2.656 4.16-4.32 7.168-4.512h1.216c3.040 0.192 5.632 1.824 7.2 4.512 1.6 2.752 1.696 6.112 0.288 8.96l-6.848 13.632c-0.128 0.288-0.352 0.512-0.64 0.64-0.192 0.096-0.384 0.16-0.608 0.16zM15.424 2.688c-2.784 0.192-5.216 1.696-6.656 4.192-1.504 2.592-1.6 5.696-0.256 8.352l6.816 13.632c0.096 0.192 0.256 0.32 0.448 0.384s0.416 0.064 0.608-0.032c0.16-0.064 0.288-0.192 0.352-0.352l6.816-13.664c1.312-2.656 1.216-5.792-0.288-8.352-1.472-2.464-3.904-4-6.688-4.16h-1.152zM16 18.208c-3.424 0-6.24-2.784-6.24-6.24 0-3.424 2.816-6.208 6.24-6.208s6.24 2.784 6.24 6.24c0 3.424-2.816 6.208-6.24 6.208zM16 6.4c-3.072 0-5.6 2.496-5.6 5.6 0 3.072 2.528 5.6 5.6 5.6s5.6-2.496 5.6-5.6c0-3.104-2.528-5.6-5.6-5.6zM16 16.16c-2.304 0-4.16-1.888-4.16-4.16s1.888-4.16 4.16-4.16c2.304 0 4.16 1.888 4.16 4.16s-1.856 4.16-4.16 4.16zM16 8.448c-1.952 0-3.552 1.6-3.552 3.552s1.6 3.552 3.552 3.552c1.952 0 3.552-1.6 3.552-3.552s-1.6-3.552-3.552-3.552z"></path> </symbol>
      </svg>
</div>

<!--Ratings HTML -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/> 
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>
<div class="container" >
<h1 class="mt-5 mb-5">  Rate&Reviews    </h1>

<div class="card">
<div class="card-header"></div>
<div class="card-body">
<div class="row">
<div class="col-sm-4 text-center">
<h1 class="text-warning mt-4 mb-4">
<b><span id="average_rating"> 0.0 </span> / 5</b>
</h1>
<div class="mb-3">
<i class="fas fa-star star-light mr-1 main_star"></i>
  <i class="fas fa-star star-light mr-1 main_star"></i>
  <i class="fas fa-star star-light mr-1 main_star"></i>
  <i class="fas fa-star star-light mr-1 main_star"></i>
  <i class="fas fa-star star-light mr-1 main_star"></i>
	</div>
  <h3><span id="total_review"> 0 </span> Review</h3>
  </div>
<div class="col-sm-4">
<p>
<div class="progress-label-left"><b>5</b> <i class="fas fa-star text-warning"></i></div>
<div class="progress-label-right">(<span id="total_five_star_review">0</span>)</div>
<div class="progress">
<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="five_star_progress"></div>
</div>
</p>
<p>
<div class="progress-label-left"><b> 4 </b> <i class="fas fa-star text-warning"></i></div>
                            
<div class="progress-label-right"> ( <span id="total_four_star_review">0</span>)</div>
<div class="progress">
<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="four_star_progress"></div>
 </div>               
 </p>
  <p>
 <div class="progress-label-left"><b>3</b> <i class="fas fa-star text-warning"></i></div>
  <div class="progress-label-right"> ( <span id="total_three_star_review"> 0 </span> ) </div>
  <div class="progress">
  <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="three_star_progress"></div>
  </div>               
  </p>
  <p>
<div class="progress-label-left"><b>2</b> <i class="fas fa-star text-warning"></i></div>
<div class="progress-label-right">(<span id="total_two_star_review">0</span>)</div>
<div class="progress">
 <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="two_star_progress"></div>
</div>               
</p>
<p>
<div class="progress-label-left"><b>1</b> <i class="fas fa-star text-warning"></i></div>
<div class="progress-label-right"> ( <span id="total_one_star_review">0</span>)</div>
<div class="progress">
<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="one_star_progress"></div>
</div>               
</p>
</div>

<!--<div class="col-sm-4 text-center">
<h3 class="mt-4 mb-3">Write Review Here</h3>
<button type="button" name="add_review" id="add_review" class="btn btn-primary">Review</button>
</div>
</div>
</div>
</div>
<div class="mt-5" id="review_content"></div>
</div> -->
</form>
</body>
</html>

<!--<div id="review_modal" class="modal" tabindex="-1" role="dialog">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Submit Review</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div> 
<div class="modal-body">
<h4 class="text-center mt-2 mb-4">
<i class="fas fa-star star-light submit_star mr-1" id="submit_star_1" data-rating="1"></i>
<i class="fas fa-star star-light submit_star mr-1" id="submit_star_2" data-rating="2"></i>
<i class="fas fa-star star-light submit_star mr-1" id="submit_star_3" data-rating="3"></i>
<i class="fas fa-star star-light submit_star mr-1" id="submit_star_4" data-rating="4"></i>
<i class="fas fa-star star-light submit_star mr-1" id="submit_star_5" data-rating="5"></i>
</h4>
<div class="form-group">
<input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter Your Name" />
</div>
<div class="form-group">
<textarea name="user_review" id="user_review" class="form-control" placeholder="Type Review Here"></textarea>
</div>
<div class="form-group text-center mt-4">
<button type="button" class="btn btn-primary" id="save_review">Submit</button>
</div>
</div>
</div>
</div>
</div> -->

<!--Ratings HTML -->
<!--Ratings JS -->
<script>

//var rating_data = 0;

//$('#add_review').click(function(){

///$('#review_modal').modal('show');

// });

//$(document).on('mouseenter', '.submit_star', function(){

//var rating = $(this).data('rating');

//reset_background();

// for(var count = 1; count <= rating; count++)
 //{

// $('#submit_star_'+count).addClass('text-warning');

// }

//  }); 

function reset_background()
{
for(var count = 1; count <= 5; count++)
{
$('#submit_star_'+count).addClass('star-light');
$('#submit_star_'+count).removeClass('text-warning');
}
}

$(document).on('mouseleave', '.submit_star', function(){

reset_background();

for(var count = 1; count <= rating_data; count++)
{

$('#submit_star_'+count).removeClass('star-light');

$('#submit_star_'+count).addClass('text-warning');
}
 });

$(document).on('click', '.submit_star', function(){

rating_data = $(this).data('rating');

});

$('#save_review').click(function(){

var user_name = $('#user_name').val();

var user_review = $('#user_review').val();

if(user_name == '' || user_review == '')
{
alert("Please Fill Both Field");
return false;
}
else
{
$.ajax({
url:"submit_rating.php",
method:"POST",
data:{rating_data:rating_data, user_name:user_name, user_review:user_review},
success:function(data)
{
$('#review_modal').modal('hide');
load_rating_data();
alert(data);
}
})
}
});




  
</script>




<script>

function confirmdelete(x){
  var result = confirm(" Do you want to delete this account? ")
}

$('#save_review').click(function(){

var user_name = $('#user_name').val();

var user_review = $('#user_review').val();

if(user_name == '' || user_review == '')
{
    alert("Please Fill Both Field");
    return false;
}
else
{
$.ajax({
url:"submit_rating.php",
method:"POST",
data:{rating_data:rating_data, user_name:user_name, user_review:user_review},
success:function(data)
{
$('#review_modal').modal('hide');

load_rating_data();
alert(data);
}
})
}

});

load_rating_data();

function load_rating_data()
{
$.ajax({
url:"submit_rating.php",
method:"POST",
data:{action:'load_data'},
dataType:"JSON",
success:function(data)
{
$('#average_rating').text(data.average_rating);
$('#total_review').text(data.total_review);

var count_star = 0;

$('.main_star').each(function(){
count_star++;
if(Math.ceil(data.average_rating) >= count_star)
{
$(this).addClass('text-warning');
$(this).addClass('star-light');
}
});

$('#total_five_star_review').text(data.five_star_review);

$('#total_four_star_review').text(data.four_star_review);

$('#total_three_star_review').text(data.three_star_review);

$('#total_two_star_review').text(data.two_star_review);

$('#total_one_star_review').text(data.one_star_review);

$('#five_star_progress').css('width', (data.five_star_review/data.total_review) * 100 + '%');

$('#four_star_progress').css('width', (data.four_star_review/data.total_review) * 100 + '%');

$('#three_star_progress').css('width', (data.three_star_review/data.total_review) * 100 + '%');

$('#two_star_progress').css('width', (data.two_star_review/data.total_review) * 100 + '%');

$('#one_star_progress').css('width', (data.one_star_review/data.total_review) * 100 + '%');

if(data.review_data.length > 0)
{
var html = '';

for(var count = 0; count < data.review_data.length; count++)
{
html += '<div class="row mb-3">';

html += '<div class="col-sm-1"><div class="rounded-circle bg-danger text-white pt-2 pb-2"><h3 class="text-center">'+data.review_data[count].user_name.charAt(0)+'</h3></div></div>';

html += '<div class="col-sm-11">';

html += '<div class="card">';

html += '<div class="card-header"><b>'+data.review_data[count].user_name+'</b></div>';

html += '<div class="card-body">';

for(var star = 1; star <= 5; star++)
{
var class_name = '';

if(data.review_data[count].rating >= star)
{
class_name = 'text-warning';
}
else
{
class_name = 'star-light';
}

html += '<i class="fas fa-star '+class_name+' mr-1"></i>';
}

html += '<br />';

html += data.review_data[count].user_review;

html += '</div>';

html += '<div class="card-footer text-right">On '+data.review_data[count].datetime+'</div>';

html += '</div>';

html += '</div>';

html += '</div>';
}

$('#review_content').html(html);
}
}
})
}

///


</script>

 <footer>
  <section class="footer">
  
    <ul class="Lf">
      <li id="foot">
          <a href="babys.html#home">Home</a>
      </li>
      <li>
          <a href="babys.html#about">About us</a>
      </li>
      <li>
          <a href="babys.html#ser">Servises</a>
      </li>
      <li>
          <a href="babys.html#foot">Contact</a>
      </li>
        
    </ul>
    
           
                    
    <p class="copyRight">
       AEN's team &#169; 2021
        </p>
      </footer>
    </section> 













 
  





</body>
</html>
