<?php
    if (isset($_POST['submit']))
    {

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");


    if (!$conn = mysqli_connect(host,Username,Password))
        die("Connection failed.");


        if(!mysqli_select_db($conn, db))
            die("Could not open the ".db." database.");



            $First_Name = $_POST['name'];
            $Last_Name = $_POST['lastname'];
            $Email = $_POST['Email'];
            $city = $_POST['city'];
            $location = $_POST['Address'];
            $Password = $_POST['Password'];
            $cPassword = $_POST['Password2'];
            $error=[];

            //if($_FILES['img']['size'] > 0){
            //  $img = $_FILES['profile-img']['tmp_name'];
              //$img = addslashes(file_get_contents($img));
        //   }
          // else{
            //    $img = null;

            $validateEmail = preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $Email);
            $specialChars = preg_match('@[^\w]@', $Password);

            if(strlen($First_Name) < 3 || (strlen($First_Name) >20))
            {
              $errors[]= "Name must be between 3 and 20";

            }



            if(!$validateEmail){
              $errors[]= "Invalid email address.";

            }

            if( !$specialChars && strlen($Password) < 8)
            {
              $errors[]="Password must be at least 8 characters and contain at least one special character #,&,..";

            }
            if(strlen($Password) < 8){
              $errors[]="Password should be at leat 8 characters";

            }

            if($cPassword != $Password)
            {
              $errors[]="Password does not match";

          }



            if( !$specialChars ) {
              $errors[]= "Password must contain at least one special character #,&,..";
              
            }

            //check if the email exits
            $query = "SELECT * FROM parent WHERE email = '$Email' ";
            $Parentresult = mysqli_query($conn,$query);


            if (mysqli_num_rows($Parentresult)>0 )
            {
              $errors[]= "Email exists!";

                $conn -> close();

            }

            $queryy="INSERT INTO `parent` VALUES ('$Password','$First_Name','$city','$location','$null','$Last_Name','$Email')";
            if (mysqli_query($conn, $queryy)) {
                echo "done" ;

                $_SESSION['Email'] = $Email ;
                header("Location: ladingP.php");
                $con -> close();
                exit;
            } else {
                echo "Error: ".mysqli_error($conn);
      }
    }







 ?>
