<!DOCTYPE html>
<?php

if(isset($_SESSION['email']))
 header("Location: ladingP.php");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Home page</title>
    <link rel="stylesheet" href="weeb.css" >
    <link rel="icon" href="icon.png" >
</head>
<body>
    <section class="cont">
        <nav id="home">
          <img src="logo.svg">
          <ul class="nav">
            <li><a href="#home">Home</a></li>
            <li><a href="#aboutus">About us</a></li>
            <li><a href="#ser">Servises</a></li>
            <li><a href="#fot">Contact</a></li>
            <li><a  class="sign" href="logIn.php">log in</a></li>
          </ul>
        </nav>

        <div class="content">

            <div class="text">
                <br><br>
                <h1>Quivkly <br> find a baby sitter</h1>
                <p>We’ll match you with a good, experienced, and reliable babysitter that suits your requirements</p>
                     <a href="SignUpP.php"  class="sign">Find child care</a>
                     <a href="signupB1.php"  class="sign">I'm a sitter</a>

            </div>






    </section>

    <!--new section about us -->
        <section class="about">

            <div class="content1">
                <h1 id="aboutus">
                    about us
                </h1>
                <p>The demands of today’s parents continue to increase every year.
                    We created this platform to connect parents with childcare professionals, and we simplified this connection,
                     which will make it easy for you and the babysitter to get in touch and have the best offers.</p>

            </div>
        </section>


        <!-- Servises-->

        <section class="servise" >
            <div class="heading">
                <h2 id="ser">Our Servises</h2>



            <div class="servise-container">

                <div class="row">
                    <h3> Babysitter </h3>
                    <p> ccasional help with last minute needs, date night, and more</p>
                    </div>


                        <div class="row">
                            <h3> Special needs </h3>
                            <p>specialized care to meet the individual needs of your child</p>
                            </div>


                                <div class="row">
                                    <h3> Tutorials </h3>
                                    <p>Educational care in subject Like math, Spanish, and reading</p>

                                    </div>




            </div>
            <br>
            <br>

        </section>

        <!-- footer-->
       <!-- footer-->
       <section class="footer">

        <ul class="Lf">
            <li>
                <a href="#home">Home</a>
            </li>
            <li>
                <a href="#aboutus">About us</a>
            </li>
            <li>
                <a href="#ser">Servises</a>
            </li>
            <li>
                <a href="#fot">Contact</a>
            </li>

        </ul>




                <ul class="icon">
                    <li id="fot">
                        <a href="">
                            <img src="twitter.png">
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <img src="linkedin.png">
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <img src="instagram.png">
                        </a>

                    </li>

                </ul>








        <p class="copyRight">
           AWN's team &#169; 2021
            </p>





        </section>


</body>
</html>
