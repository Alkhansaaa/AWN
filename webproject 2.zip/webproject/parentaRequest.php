<!DOCTYPE html>

<?php
session_start();
if(!isset($_SESSION['Email'])){
  header("Location: ../wep.php");
}
?>

<html>
  <head>
    <meta charset="UTF-8">
    <title> complete request </title>
    <link rel="stylesheet" href="parentaRequest.css">
    <link rel="icon" href="icon.png" >

    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="parentaRequest" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <section class="cont">
    <nav>
      <a href="ladingP.php"> <h2>AWN</h2> </a>
      <ul class="nav">
        <li><a href="ladingP.php#home">Home</a></li>
        <li><a href="ladingP.php#about">About us</a></li>
        <li><a href="ladingP.php#ser">Servises</a></li>
        <li><a href="ladingP.php#foot">Contact</a>
        </li>

       <li><a  class="user" href="logout.php">
           <img src="logout.png" >
           </a>

           <div class="dropdown">
               <button class="dropbtn"><img src="profile.png"></button>
               <div class="dropdown-content">
                <a href="profiles.php">Edit profile</a>
                <a href="booking.php">My Booking</a>
      <a href="offerslistPR.php">Offers</a>
      <a href="reqlistPR.php">My Requests</a>
              </div>
            </div>


           </button>
           </a>
      </li>
     </ul>
   </nav>
  </section>


<div class="container">
  <p>
      <h2>complete request info</h2>
      <form method="post" action="RequestP.php"  >
      <div class="col-75">

        <div class="row">

          <div class="col-25">
            <label for="name"> kids name </label>
            <input type="text" id="name" name="Itemname" placeholder="kids name..">
          </div>

      <div class="row">
      <div class="col-25">
        <label for="number"  > Number of kids </label>
        <select name="number" id="number" >
          <option  value="1">1</option>
          <option  value="2">2 </option>
          <option  value="3" >3</option>
          <option  value="4">4 </option>
          <option  value="5">5</option>
          <option  value="6">6</option>
        </select>
       </div>
     <div class="col-25">
     <label for="Duration"> Duration </label>
        <select name="Duration" id="Duration" >
          <option  value="1">1-2 hours</option>
          <option  value="2">2-3 hours </option>
          <option  value="3" >3-4 hours</option>
          <option  value="4">4-5 hours </option>
          <option  value="5">5-6 hours</option>
          <option  value="6">6-7 hours</option>
        </select>


  </div>
</p>

   <!--<div class="row">
      <div class="col-75">
        <label for="Kids info">Kids info</label>
        <input type="text" id="Price" name="Price" placeholder="Kids info..">
        </div>
    </div>-->

  <div class="row">
    <div class="col-256">
      <label for="date">Date</label>
      <br>
      <input type="date" id="Date" name="Date">

   </div>

        <div class="col-25">
         <label for="age"> kids age </label>
         <select name="age" id="age" >
          <option  value="1">one year</option>
          <option  value="2"> 2years </option>
          <option  value="3">3years</option>
          <option  value="4">4years </option>
          <option  value="5">5years</option>
          <option  value="6">6years</option>
          <option  value="7">7years</option>
          <option  value="8">8years</option>
          <option  value="9">9years</option>
          <option  value="10">10years</option>
          <option  value="11">11years</option>
          <option  value="12">12years</option>
        </select>
        </div>

  <div class="row">
    <br>
      <div class="col-75">
        <label for="category">Type of service</label>
        <select name="category" id="category">
          <option  value="infant babysitting">infant babysitting</option>
          <option  value="homework help">homework help </option>
          <option  value="structuring activties" >structuring activtie s</option>
          <option  value="special needs">special needs </option>
          <option  value="other">other</option>
        </select>
       </div>
     </div>
</form>



     <br>

      <input type="Submit" value="send request" >
      <input type="submit" value="cancel request">

    </div>



</div>
<footer>
<section class="footer">

  <ul class="Lf">
    <li id="foot">
        <a href="ladingP.php#home">Home</a>
    </li>
    <li>
        <a href="ladingP.php#about">About us</a>
    </li>
    <li>
        <a href="ladingP.php#ser">Servises</a>
    </li>
    <li>
        <a href="ladingP.php#foot">Contact</a>
    </li>

  </ul>

          <ul class="icon">
              <li>
                  <a href="">
                      <img src="twitter.png">
                  </a>
              </li>
              <li>
                  <a href="#">
                      <img src="linkedin.png">
                  </a>
              </li>
              <li>
                  <a href="">
                      <img src="instagram.png">
                  </a>
              </li>


  <p class="copyRight">
     Aon team &#169; 2021
      </p>
    </footer>
  </section>






</body>
</html>
