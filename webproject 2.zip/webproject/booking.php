<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION['Email'])){
  header("Location: web.php");
}
?>
<html lang="en" id="booking">
<head>
  <meta charset="UTF-8">
  <title>Booking</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <link rel="stylesheet" href="styles/bookingstyle.css">
  <link rel="icon" href="icon.png" >
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
   

  <?php
  ini_set('display_errors',1); 
  error_reporting(E_ALL);
  
   Define("host","localhost");
   Define("Username", "root");
   Define("Password", "");
   Define("db", "AWN'S");
  
  
  
   $connection = mysqli_connect(host,Username,Password,db);
   if(!$connection){
     print("<p>could not connect to database</p>");
     die("could not connect to the db </html>");
   
   }
   $email=$_SESSION['Email'];
   $query="SELECT * FROM bookingandjobs WHERE parent_email='$email'";
   
   
   
   $result=mysqli_query($connection,$query);
   
   
  ?>


</head>
<body>
<!-- partial:index.partial.html -->
<header class="cont">
  
  <nav>
    <a href="ladingP.html"> <h2>AWN</h2> </a>
   <ul class="nav">
     <li><a href="ladingP.php#home">Home</a></li>
     <li><a href="ladingP.php#about">About us</a></li>
     <li><a href="ladingP.php#ser">Servises</a></li>
     <li><a href="ladingP.php#foot">Contact</a>
     </li>

     <li><a  class="user" href="web.php">
         <img src="logout.png" >
         </a>

         <div class="dropdown">
             <button class="dropbtn"><img src="profile.png"></button>
             <div class="dropdown-content">
              <a href="profiles.php">Edit profile</a>
              <a href="booking.php">My Booking</a>
    <a href="offerslistPR.php">Offers</a>
    <a href="reqlistPR.php">My Requests</a>
            </div>
          </div>
           
           
         </button>
         </a>
    </li>
   </ul>
 </nav>
    </header>



<div class="Current">
<h1 class="title">Current Booking</h1>

<div class="slider" x-data="{start: true, end: false}">
  <div class="slider__content" x-ref="slider" x-on:scroll.debounce="$refs.slider.scrollLeft == 0 ? start = true : start = false; Math.abs(($refs.slider.scrollWidth - $refs.slider.offsetWidth) - $refs.slider.scrollLeft) < 5 ? end = true : end = false;">
    
    
<?php
while($row=mysqli_fetch_row($result)){ 
   $query2="SELECT * FROM request WHERE request_id='$row[1]'AND reqdate>=(CAST(CURRENT_TIMESTAMP AS DATE))";
    $result2=mysqli_query($connection,$query2);
    while($row2=mysqli_fetch_row($result2)){  
   ?>
<div class="slider__item">
    <h2><?php echo $row2[4]?></h2>
    <div class="cslider__info">
      <h3><a href=""><?php echo $row[3]?></a></h3>
     
      <h3>Duration:<?php echo $row2[8]?> Hours</h3>
      <h3><?php echo $row[1]?></h3></div>
</div>
<?php } } ?>


    

  </div>
  <div class="slider__nav">
    <button class="slider__nav__button" x-on:click="$refs.slider.scrollBy({left: $refs.slider.offsetWidth * -1, behavior: 'smooth'});" x-bind:class="start ? '' : 'slider__nav__button--active'">Previous</button>
    <button class="slider__nav__button" x-on:click="$refs.slider.scrollBy({left: $refs.slider.offsetWidth, behavior: 'smooth'});" x-bind:class="end ? '' : 'slider__nav__button--active'">Next</button>
  </div>
</div>
<hr>
<div class="Previous">
    <h1 class="title">Previous Booking</h1>
    
    <div class="slider" x-data="{start: true, end: false}">
      <div class="slider__content" x-ref="slider" x-on:scroll.debounce="$refs.slider.scrollLeft == 0 ? start = true : start = false; Math.abs(($refs.slider.scrollWidth - $refs.slider.offsetWidth) - $refs.slider.scrollLeft) < 5 ? end = true : end = false;">
 
        
       
        
        
       
       
        
        
        
        

      <?php
$query4="SELECT * FROM bookingandjobs WHERE babysitter_email='joey@gmail.com'";
         
$result4=mysqli_query($connection,$query4);
    
while($row4=mysqli_fetch_row($result4)){ 
    

   $query3="SELECT * FROM request WHERE request_id='$row4[1]'AND reqdate<(CAST(CURRENT_TIMESTAMP AS DATE))";
    $result3=mysqli_query($connection,$query3);
   
  while($row3=mysqli_fetch_row($result3)){
    $_SESSION['EmailB']=$row4[3];//to view babysitter profile
   ?>

<div class="slider__item">
            <h2><?php echo $row3[4]?></h2>
            <div class="pslider__info">
              <a href="babySP.php"><h3><?php echo $row4[3]?></h3></a>
              <h3>#booking number</h3>
              <h3>Duration:<?php echo $row3[8]?> Hours</h3>
              <h3><?php echo $row3[2]?></h3>
              <div class="rating">
              <button type="button" name="add_review" id="add_review" class="btn btn-primary">Review</button>

           
          </div>
          
        </div>
        </div>



        <?php } }?>











      </div>

      <div class="slider__nav">
        <button class="slider__nav__button" x-on:click="$refs.slider.scrollBy({left: $refs.slider.offsetWidth * -1, behavior: 'smooth'});" x-bind:class="start ? '' : 'slider__nav__button--active'">Previous</button>
        <button class="slider__nav__button" x-on:click="$refs.slider.scrollBy({left: $refs.slider.offsetWidth, behavior: 'smooth'});" x-bind:class="end ? '' : 'slider__nav__button--active'">Next</button>
      </div>
    </div>
</div>
<!-- partial -->
<footer class="footer">
  
  
  <ul class="Lf">
    <li id="foot">
        <a href="ladingP.html#home">Home</a>
    </li>
    <li>
        <a href="ladingP.html#about">About us</a>
    </li>
    <li>
        <a href="ladingP.html#ser">Servises</a>
    </li>
    <li>
        <a href="ladingP.html#foot">Contact</a>
    </li>
    
</ul>
    
            <ul class="icon">
                <li>
                    <a href="">
                        <img src="twitter.png">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="linkedin.png">
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="instagram.png">
                    </a>
                </li>  
                     
  
    <p class="copyRight">
       AWN'S team &#169; 2021
        </p>
      </footer>





<script> 
   
   //
      var rating_data = 0;
   
   $('#add_review').click(function(){
   
       $('#review_modal').modal('show');
   
   });
   
   $(document).on('mouseenter', '.submit_star', function(){
   
       var rating = $(this).data('rating');
   
       reset_background();
   
       for(var count = 1; count <= rating; count++)
       {
   
           $('#submit_star_'+count).addClass('text-warning');
   
       }
   
   });
   
   function reset_background()
   {
       for(var count = 1; count <= 5; count++)
       {
   
           $('#submit_star_'+count).addClass('star-light');
   
           $('#submit_star_'+count).removeClass('text-warning');
   
       }
   }
   
   $(document).on('mouseleave', '.submit_star', function(){
   
       reset_background();
   
       for(var count = 1; count <= rating_data; count++)
       {
   
           $('#submit_star_'+count).removeClass('star-light');
   
           $('#submit_star_'+count).addClass('text-warning');
       }
   
   });
   
   $(document).on('click', '.submit_star', function(){
   
       rating_data = $(this).data('rating');
   
   });
   
   $('#save_review').click(function(){
   
       var user_name = $('#user_name').val();
   
       var user_review = $('#user_review').val();
   
       if(user_name == '' || user_review == '')
       {
           alert("Please Fill Both Field");
           return false;
       }
       else
       {
           $.ajax({
               url:"submit_rating.php",
               method:"POST",
               data:{rating_data:rating_data, user_name:user_name, user_review:user_review},
               success:function(data)
               {
                   $('#review_modal').modal('hide');
   
                   load_rating_data();
   
                   alert(data);
               }
           })
       }
   
   });
   //
   
   
   $('#save_review').click(function(){
   
   var user_name = $('#user_name').val();
   
   var user_review = $('#user_review').val();
   
   if(user_name == '' || user_review == '')
   {
       alert("Please Fill Both Field");
       return false;
   }
   else
   {
       $.ajax({
           url:"submit_rating.php",
           method:"POST",
           data:{rating_data:rating_data, user_name:user_name, user_review:user_review},
           success:function(data)
           {
               $('#review_modal').modal('hide');
   
               load_rating_data();
   
               alert(data);
           }
       })
   }
   
   });
   
   load_rating_data();
   
   function load_rating_data()
   {
   $.ajax({
       url:"submit_rating.php",
       method:"POST",
       data:{action:'load_data'},
       dataType:"JSON",
       success:function(data)
       {
           $('#average_rating').text(data.average_rating);
           $('#total_review').text(data.total_review);
   
           var count_star = 0;
   
           $('.main_star').each(function(){
               count_star++;
               if(Math.ceil(data.average_rating) >= count_star)
               {
                   $(this).addClass('text-warning');
                   $(this).addClass('star-light');
               }
           });
   
           $('#total_five_star_review').text(data.five_star_review);
   
           $('#total_four_star_review').text(data.four_star_review);
   
           $('#total_three_star_review').text(data.three_star_review);
   
           $('#total_two_star_review').text(data.two_star_review);
   
           $('#total_one_star_review').text(data.one_star_review);
   
           $('#five_star_progress').css('width', (data.five_star_review/data.total_review) * 100 + '%');
   
           $('#four_star_progress').css('width', (data.four_star_review/data.total_review) * 100 + '%');
   
           $('#three_star_progress').css('width', (data.three_star_review/data.total_review) * 100 + '%');
   
           $('#two_star_progress').css('width', (data.two_star_review/data.total_review) * 100 + '%');
   
           $('#one_star_progress').css('width', (data.one_star_review/data.total_review) * 100 + '%');
   
           if(data.review_data.length > 0)
           {
               var html = '';
   
               for(var count = 0; count < data.review_data.length; count++)
               {
                   html += '<div class="row mb-3">';
   
                   html += '<div class="col-sm-1"><div class="rounded-circle bg-danger text-white pt-2 pb-2"><h3 class="text-center">'+data.review_data[count].user_name.charAt(0)+'</h3></div></div>';
   
                   html += '<div class="col-sm-11">';
   
                   html += '<div class="card">';
   
                   html += '<div class="card-header"><b>'+data.review_data[count].user_name+'</b></div>';
   
                   html += '<div class="card-body">';
   
                   for(var star = 1; star <= 5; star++)
                   {
                       var class_name = '';
   
                       if(data.review_data[count].rating >= star)
                       {
                           class_name = 'text-warning';
                       }
                       else
                       {
                           class_name = 'star-light';
                       }
   
                       html += '<i class="fas fa-star '+class_name+' mr-1"></i>';
                   }
   
                   html += '<br />';
   
                   html += data.review_data[count].user_review;
   
                   html += '</div>';
   
                   html += '<div class="card-footer text-right">On '+data.review_data[count].datetime+'</div>';
   
                   html += '</div>';
   
                   html += '</div>';
   
                   html += '</div>';
               }
   
               $('#review_content').html(html);
           }
       }
   })
   }
   
   
   
   
       
</body>
</html>


<form method="get" id="form1" action="php/addreview.php">
<div id="review_modal" class="modal" tabindex="-1" role="dialog">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" >Submit Review</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
	        	</button>
	      	</div>
	      	<div class="modal-body">
	      		<h4 class="text-center mt-2 mb-4">
	        		<input type="checkbox" name="rate" id="rate-1" value="1">
                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_1" for="rate-1" data-rating="1"></i>
                    <input type="checkbox" name="rate" id="rate-2" value="2">
                     <i class="fas fa-star star-light submit_star mr-1" id="submit_star_2" for="rate-2" data-rating="2"></i>
                    <input type="checkbox" name="rate" id="rate-3" value="3">
                      <i class="fas fa-star star-light submit_star mr-1" id="submit_star_3"for="rate-3" data-rating="3"></i>
                    <input type="checkbox" name="rate" id="rate-4" value="4">

                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_4" for="rate-4" data-rating="4"></i>
                    <input type="checkbox" name="rate" id="rate-5" value="5">

                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_5"for="rate-5" data-rating="5"></i>
	        	</h4>
	        	<div class="form-group">
	        		<input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter Your Name" />
	        	</div>
	        	<div class="form-group">
	        		<textarea name="user_review" id="user_review" class="form-control" placeholder="Type Review Here"></textarea>
	        	</div>
	        	<div class="form-group text-center mt-4">
	        		<button type="submit" class="btn btn-primary" id="save_review">Submit</button>
	        	</div>
	      	</div>
    	</div>
  	</div>
</form>

 
<form method="get" id="form1" action="php/addreview.php">
<div id="review_modal" class="modal" tabindex="-1" role="dialog">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" >Submit Review</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
	        	</button>
	      	</div>
	      	<div class="modal-body">
	      		<h4 class="text-center mt-2 mb-4">
	        		<input type="checkbox" name="rate" id="rate-1" value="1">
                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_1" for="rate-1" data-rating="1"></i>
                    <input type="checkbox" name="rate" id="rate-2" value="2">
                     <i class="fas fa-star star-light submit_star mr-1" id="submit_star_2" for="rate-2" data-rating="2"></i>
                    <input type="checkbox" name="rate" id="rate-3" value="3">
                      <i class="fas fa-star star-light submit_star mr-1" id="submit_star_3"for="rate-3" data-rating="3"></i>
                    <input type="checkbox" name="rate" id="rate-4" value="4">

                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_4" for="rate-4" data-rating="4"></i>
                    <input type="checkbox" name="rate" id="rate-5" value="5">

                    <i class="fas fa-star star-light submit_star mr-1" id="submit_star_5"for="rate-5" data-rating="5"></i>
	        	</h4>
	        	<div class="form-group">
	        		<input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter Your Name" />
	        	</div>
	        	<div class="form-group">
	        		<textarea name="user_review" id="user_review" class="form-control" placeholder="Type Review Here"></textarea>
	        	</div>
	        	<div class="form-group text-center mt-4">
	        		<button type="submit" class="btn btn-primary" id="save_review">Submit</button>
	        	</div>
	      	</div>
    	</div>
  	</div>
</form>

 
 
 
 