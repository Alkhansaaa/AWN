
<!DOCTYPE html>



<?php


$email = $_SESSION['EmailB'];


ini_set('display_errors',1); 
error_reporting(E_ALL);

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");


    if (!$conn = mysqli_connect(host,Username,Password))
        die("Connection failed.");


        if(!mysqli_select_db($conn, db))
            die("Could not open the ".db." database.");

            $query = "SELECT * FROM request WHERE  reqstatus = 'pending'"; //date >" ;
            $result = mysqli_query($conn, $query);
            

           // $queryD= "SELECT date from request where (Status = 'pending')";
           // $resultD= mysqli_query($conn, $queryD);

?>

<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Requests List</title>
  <link rel="stylesheet" href="reqlistBSstyle.css">
  <link rel="icon" href="icon.png" >
  
</head>
<body>
<!-- partial:index.partial.html -->

<header class="cont">

  <nav>
    <a href="babys.php"> <h2>AWN</h2> </a>
    <ul class="nav">
        <li><a href="babys.php">Home</a></li>
        <li><a href="babys.php#about">About us</a></li>
        <li><a href="babys.php#ser">Servises</a></li>
        <li><a href="babys.php#foot">Contact</a>
        </li>

    <li><a  class="user" href="logout.php">
        <img src="logout.png" >
        </a>

        <div class="dropdown">
          <button class="dropbtn"><img src="profile.png"></button>
          <div class="dropdown-content">
              <a href="babysitter.php">Edit profile</a>
            <a href="jobs.php">jobs</a>
            <a href="offerslistBS.php">My Offers</a>
          </div>
        </div>



        </button>
        </a>
   </li>
  </ul>
</nav>
    </header>

<div class="cards">
  <h1>Requests</h1>
  <hr>
  
    




      <?php

    
      while($row=mysqli_fetch_row($result))
      {
      ?>
       <div class="card">
       <div class="card__image-holder">
      <h2>
        type of service <? echo $row[4]; ?>
      </h2>
      <h3>
        duration <? echo $row[8];?>
      </h3>

      
      <h3>
        <?php
        $found=false;
        $query2 = "SELECT reuest_id FROM bookingandjobs WHERE  babysitter_email = '$email'"; //get req id in the babysitter jobs  ;
        $result2 = mysqli_query($conn, $query2);
        while($row2=mysqli_fetch_row($result2)){
          $query3 = "SELECT reqdate FROM request WHERE  request_id = '$row2[0]'";
          $result3 = mysqli_query($conn, $query3);
          $jobdate=mysqli_fetch_row($result3);
          
          if($row[2]==$jobdate[0])
          $found=true;

        }
        $query4 = "SELECT request_id FROM offers WHERE  babysitter_email = '$email' AND offerstatus!='rejected'"; //get req id in the babysitter jobs  ;
        $result4 = mysqli_query($conn, $query4);
        while($row4=mysqli_fetch_row($result4)){
          $query5 = "SELECT reqdate FROM request WHERE  reuest_id = '$row4[0]'";
          $result5 = mysqli_query($conn, $query5);
          $offerdate=mysqli_fetch_row($result5);
          
          if($row[2]==$offerdate[0])
          $found=true;

        }
        
        if($found==false){
          
          $_SESSION['premail']=$row[7];
          echo $_SESSION['premail']."yaaay";
         
         ?>
        <form action="babySitterOffer.php" method="get" id="form1">
      <button  class="btn" form="form1" type="submit" name="premail" value="<?php echo $row[7]; ?>">Send offer</a></h3>
      
    
    <?php } ?>
    </form>

    </div>
    <div class="card-title">
      <a href="#" class="toggle-info btn">
        <span class="left"></span>
        <span class="right"></span>
      </a>
      <h3>
        <h3> <a href="#"><?php echo $row[7] ;?></a></h3>
        <small>#number of request <?php echo $row[1] ;?> </small>
      </h3>
    </div>
    <div class="card-flap flap1">
     <div class="card-description">
        details
        <h2>
          Name Of kids<? echo $row[5]; ?>
        </h2>
        <h2>
          Parent Email<? echo $row[7]; ?>
        </h2>
      </div>
      <div class="card-flap flap2">
        <div class="card-actions">
        </div>
      </div>
    </div>
  </div>
  <?php
  }

  ?>

</div>



<!-- partial -->
<footer class="footer">


  <ul class="Lf">
    <li id="foot">
        <a href="babys.php#home">Home</a>
    </li>
    <li>
        <a href="babys.php#about">About us</a>
    </li>
    <li>
        <a href="babys.php#ser">Servises</a>
    </li>
    <li>
        <a href="babys.php#foot">Contact</a>
    </li>

  </ul>

          <ul class="icon">
              <li>
                  <a href="">
                      <img src="twitter.png">
                  </a>
              </li>
              <li>
                  <a href="#">
                      <img src="linkedin.png">
                  </a>
              </li>
              <li>
                  <a href="">
                      <img src="instagram.png">
                  </a>
              </li>


  <p class="copyRight">
     AWN'S team &#169; 2021
      </p>
    </footer>
</body>
</html>
