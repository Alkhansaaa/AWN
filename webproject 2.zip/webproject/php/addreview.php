<?php


ini_set('display_errors',1); 
error_reporting(E_ALL);

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");



 
$connection = mysqli_connect(host,Username,Password,db);
if(!$connection){
  print("<p>could not connect to database</p>");
  die("could not connect to the db </html>");

}if($connection)
echo "connection ";

if(!isset($_GET['rate'])){
$rate=0;

}else{
    if($_GET['rate']==5){
        $rate=5;
  
    }else if($_GET['rate']==4){
        $rate=4;
  
    }else if($_GET['rate']==3){
        $rate=3;
  
    }else if($_GET['rate']==2){
        $rate=2;
  
    }else if($_GET['rate']==1){
        $rate=1;
  
    }
}


if(isset($_GET['user_name'])){
    $username=$_GET['user_name'];
}


if(isset($_GET['user_review'])){
    $review=$_GET['user_review'];
}

$query="INSERT INTO `review_and_rate`(`rate`, `review`, `babysitter_email`, `username`) VALUES ('$rate','$review','joey@gmail.com','$username')";
$result1= mysqli_query($connection,$query);





?>