<?php

ini_set('display_errors',1); 
error_reporting(E_ALL);

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");


 
$connection = mysqli_connect(host,Username,Password,db);
if(!$connection){
  print("<p>could not connect to database</p>");
  die("could not connect to the db </html>");

}if($connection)
echo "connection ";

if(isset($_GET['accept'])){
    echo "you got in delete";

$id=$_GET['accept'];
$query="SELECT * FROM offers WHERE offer_id=".$id;
//$query="SELECT * FROM offers WHERE offer_id=".$id;
$result= mysqli_query($connection,$query);
$row=mysqli_fetch_row($result);

$query2="UPDATE offers SET price='$row[1]',parent_email='$row[2]',babysitter_email='$row[3]',request_id='$row[4]',offerstatus='accepted' WHERE offer_id='$row[0]'";//change offer status to accepted
$result2= mysqli_query($connection,$query2);
if($result2)
echo 'offer status has changed';
else
echo 'offer status faled to changed :(';

//add the offer to booking and jobs table

$query3="INSERT INTO `bookingandjobs`(`reuest_id`, `parent_email`, `babysitter_email`) VALUES ('$row[4]','$row[2]','$row[3]')";
$result3= mysqli_query($connection,$query3);
if($result3)
echo 'offer added to booking';
else
echo 'not added to booking :(';
}
if(isset($_GET['reject'])){
    echo "you got in reject";

$id=$_GET['reject'];
$query="SELECT * FROM offers WHERE offer_id=".$id;
$result= mysqli_query($connection,$query);
$row=mysqli_fetch_row($result);
$query2="UPDATE offers SET price='$row[1]',parent_email='$row[2]',babysitter_email='$row[3]',request_id='$row[4]',offerstatus='rejected'WHERE offer_id='$row[0]'";//change offer status to rejected
$result2= mysqli_query($connection,$query2);

if($result2)
echo 'offer status has changed';
else
echo 'offer status faled to changed :(';


}
?>