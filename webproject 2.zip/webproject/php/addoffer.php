<?php


ini_set('display_errors',1); 
error_reporting(E_ALL);

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");

echo "you got in";

 
$connection = mysqli_connect(host,Username,Password,db);
if(!$connection){
  print("<p>could not connect to database</p>");
  die("could not connect to the db </html>");

}if($connection)
echo "connection ";

if(isset($_GET['Price'])){
    session_start();

$price=$_GET['Price'];
$email = $_SESSION['EmailB'];


$query="INSERT INTO offers( `price`, `parent_email`, `babysitter_email`, `request_id`, `offerstatus`) VALUES ('$price','parent_email?','','$email','pending')";
$result1= mysqli_query($connection,$query);


}


?>