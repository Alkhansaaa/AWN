<!DOCTYPE html>
<?php
    session_start();
    // Check if the user has already logged in
    if(isset($_SESSION['EmailB']))
        // header() is used to send a raw HTTP header. It must be called before any actual output is sent.
        header("Location: babys.php");

        ?>
<html>

<head>
  <meta charset="utf-8">
  <title>Register Form</title>
<link rel="stylesheet" href="login.css">
<link rel="icon" href="icon.png" >
<script src="JS/Validations.js"></script>
</head>

<body>

  <section class="cont">
    <nav>
      <a href="web.php"> <h2>AWN</h2> </a>
          <ul class="nav">
        <li><a href="web.php#home">Home</a></li>
        <li><a href="web.php#aboutus">About us</a></li>
        <li><a href="web.php#ser">Servises</a></li>
        <li><a href="web.php#fot">Contact</a>
        </li>


       </li>
      </ul>
    </nav>
  </section>

  <!-------------------Register------------->

  <div class="center11">
    <h1>Sign up</h1>
    <h2> Enter your details to continue </h2>

    <div id="addinPic" class="d-flex flex-column align-self-center mt-4">
      <img id="profile-image" src="images/undraw_profile_pic_ic.png" alt="pet picture">
      <input type="file" id="uploadFile" name="profile-img">
      <label class="align-self-end" for="uploadFile"><i class="bi bi-plus-circle-fill" id="plusS"></i></label>
      <div class="col-9">
       <div class="customUpload btnUpload btnM">
       <input id="file" type="file" onchange="loadFile(event)"/>
       </div>
     </div>
   </div>
   <?php include('signupB.php'); ?>
       <div id="error"></div>
         <form id="form" action="signupB1.php" method="post">
           <?php if(isset($errorB)){
             if(! empty($errorB)){
               foreach ($errorB as $errorB) { ?>
                 <script>
                 document.getElementById('center111').style.height = '1200px';

                 </script>
                 <p id="error" style="color:Red;" > <?php echo "*".$errorB; ?> </p>

               <?php }
             }
           } ?>

      <div class="txt_field">
        <input type="fname"  id="fname" name="fname" required>
        <span></span>
        <label>*First name</label>
      </div>


      <div class="txt_field">
        <input type="lname" id="lname" name="lname" required>
        <span></span>
        <label>*Last name</label>
      </div>


      <div class="txt_field">
        <input type="Email" id="Email" name="Email" required>
        <span></span>
        <label>*Email </label>
      </div>


      <div class="txt_field">
        <input type="ID" id="ID" name="ID" required>
        <span></span>
        <label>*ID </label>
      </div>


      <div class="txt_field">
        <input type="tel" id="phone" name="phone" required>
        <span></span>
        <label>*Phone number</label>
      </div>

      <div class="txt_field">
        <input type="Password" id="Password" name="Password" required>
        <span></span>
        <span></span>
        <label>*Create your Password</label>
      </div>


      <div class="txt_field">
        <input type="Password" id="Password" name="Password1" required>
        <span></span>
        <label>*Confirm password</label>
      </div>





      <div class="txt_field">
        <input type="text" required name="age">
        <span></span>
        <label>*Age </label>
      </div>

      <div class="txt-field">
        <div class="mb-3">
          <select class="form-select" required aria-label="select example" name='city'>
            <option value="">*City</option>
        <option> Riyadh </option>
        <option> Jeddah</option>
        <option> Makkah </option>
        <option> Dammam</option>
        <option> Madinah </option>

          </select>
        </div>
</div>


      <div class="d-flex justify-content-between">
        <label class="col-3">
                <span>Gender</span>
                <br>
                <input class="mt-3" name="gender" type="radio" value="male">
                <span>male</span>
                <input class="mt-3" name="gender" type="radio" value="female">
                <span>female</span>
            </label>
        </div>
<br>


      <div class="txt_field">

        <input type="textarea" name="Bio" id="Bio" required>

        <label>*Bio "Years of experiens,Education,Spoken languages,Skills....."" </label>
        <span></span>

        </div>
<br>

        <div class="col-12">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
            <label class="form-check-label" for="invalidCheck">
              I agree with terms and privacy policy
            </label>
         <br>
        <input type="submit" name="submit1" value="Signup">

      <div class="signup_link">
          Have an account ? <a href="logIn.php">Login here</a>
    </form>
  </div>
  <br>
  <br>
  <script>

</script>




</body>

</html>
