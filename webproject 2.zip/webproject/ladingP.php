<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION['Email'])){
  header("Location: web.php");
}
  ?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AWN</title>
    <link rel="stylesheet" href="weeb.css" >
    <link rel="icon" href="icon.png" >
</head>
<body>
    <section class="cont">
        <nav id="home">
           <img src="logo.svg">
          <ul class="nav">
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About us</a></li>
            <li><a href="#ser">Servises</a></li>
            <li><a href="#foot">Contact</a>
            </li>

            <li><a  class="user" href="logout.php">
                <img src="logout.png" >
                </a>

                <div class="dropdown">
                    <button class="dropbtn"><img src="profile.png"></button>
                    <div class="dropdown-content">
                      <a href="ParentProfile.php">Edit profile</a>
                      <a href="booking.php">My Booking</a>
            <a href="offerslistPR.php">Offers</a>
            <a href="reqlistPR.php">My Requests</a>
                    </div>
                  </div>


                </button>
                </a>
           </li>
          </ul>
        </nav>

        <div class="content">

            <div class="text">
                <br><br>
                <h1> your next appointment</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae,
                     aperiam distinctio qui consectetur repudiandae sapiente, debitis
                      possimus impedit placeat
                     cumque alias numquam provident ipsum nulla itaque adipisci in
                     necessitatibus voluptates.</p>
                     <a href="parentaRequest.php"  id="joun"class="sign">Create Request</a>

            </div>






    </section>

    <!--new section about us -->
        <section class="about">

            <div class="content1">
                <h1 id="about">
                    about us
                </h1>
                <p>The demands of today’s parents continue to increase every year.
                    We created this platform to connect parents with childcare professionals, and we simplified this connection,
                     which will make it easy for you and the babysitter to get in touch and have the best offers.</p>
                </p>

            </div>
        </section>


        <!-- Servises-->

        <section class="servise" >
            <div class="heading">
                <h2 id="ser">Our Servises</h2>



            <div class="servise-container">

                <div class="row">
                    <img src="need.png"><br>
                    <h3> Special needs </h3>

                    </div>


                        <div class="row">
                            <img src="question-mark.png"><br>
                            <h3> homework help </h3>

                            </div>


                                <div class="row">
                                    <img src="inf.png"><br>
                                    <h3> infant babysitting </h3>

                                    </div>




            </div>
            <br>
            <br>

        </section>

        <!-- footer-->
        <section class="footer">

        <ul class="Lf">
            <li id="foot">
                <a href="#home">Home</a>
            </li>
            <li>
                <a href="#about">About us</a>
            </li>
            <li>
                <a href="#ser">Servises</a>
            </li>
            <li>
                <a href="#foot">Contact</a>
            </li>

        </ul>





                <ul class="icon">
                    <li>
                        <a href="">
                            <img src="twitter.png">
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <img src="linkedin.png">
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <img src="instagram.png">
                        </a>
                    </li>








        <p class="copyRight">
           AWN'S team &#169; 2021
            </p>





        </section>



</body>
</html>
