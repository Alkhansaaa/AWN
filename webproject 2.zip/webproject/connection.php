<?php



Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");

ini_set('display_errors',1); 
error_reporting(E_ALL);

echo "you got in";

 
$connection = mysqli_connect(host,Username,Password,db);
if(!$connection){
  print("<p>could not connect to database</p>");
  die("could not connect to the db </html>");

}
 ?>