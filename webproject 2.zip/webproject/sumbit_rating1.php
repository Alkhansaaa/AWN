<!DOCTYPE html
<?php 

//The code below make the database connection :

$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");
if(isset($_POST["rating_data"]))
{

	$data = array(
		':user_name'		=>	$_POST["user_name"],
		':user_rating'		=>	$_POST["rating_data"],
		':user_review'		=>	$_POST["user_review"],
		':datetime'			=>	time()
    );

  
  //
ini_set('display_errors',1); 
error_reporting(E_ALL);
     
    
    Define("host","localhost");
    Define("Username", "root");
    Define("Password", "");
    Define("db", "AWN'S");
    
    
    $connection = mysqli_connect(host,Username,Password,db);
    if(!$connection){
      print("<p>could not connect to database</p>");
      die("could not connect to the db </html>");
    
    }
    
    $query="SELECT * FROM review_and_rate"; 
    
    $result=mysqli_query($connection,$query);
//





//$query = "
//INSERT INTO review_table 
//(user_name, user_rating, user_review, datetime) 
//VALUES (:user_name, :user_rating, :user_review, :datetime)
//"; 
    
$query = "
INSERT INTO review_and_rate
(`id`, `rate`, `review`, `parent_email`, `babysitter_email`)
VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]' ) 
"   
; 


$statement = $connest->prepare($query); 
$statement -> execute($data); 
echo "Your Review & Rating Sucessfully Submitted"; 

}

if(isset($_POST["action"]))
{
    $average_rating=0; 
    $tatal_review=0;
    $five_star_review=0;
    $three_star_review=0;
    $two_star_review =0;
    $one_star_review =0;
    $total_user_rating=0;
    $review_content= array();

    $query ="
    SELECT * FROM review_table
    ORDERD BY review_id DESC";
    $result= $connect->query($query, PDO:: FETCH_ASSOC);

    foreach($result as $row)
    {
        $review_content[]= array(
            'user_name' => $row["user_name"],
            'user_review' => $row["user_review"],
            'rating' => $row["user_rating"],
            'datetime' => date('1 JS, F Y h:i:s A',$row["datetime"])
        );

if($row["user_rating"]=='5')
{
    
    $five_star_review++;
}
if($row["user_rating"]== '4')
{
    $four_star_review++;
}
if($row["user_rating"]== '3')
{
    $three_star_review++; 
}
if($row["user_rating"]== '2')
{
    $two_star_review++; 
}
if($row["user_rating"]== '1')
{
    $one_star_review++; 
}

$total_review++;

$total_user_rating = $total_review + $row["user_rating"];
}

$average_rating = $total_user_rating / $total_review ; 
$output = array(
    'avarage_rating' => number_format($average_rating, 1),
    'total_review'   => $total_review,
    'five_star_review' => $five_star_review,
    'four_star_review' => $four_star_review,
    'three_star_review' => $three_star_review,
    'two_star_review' => $two_star_review,
    'one_star_review' => $one_star_review,
    'review_date' => $review_content
);
echo json_encode($output);
}


//ReviewCommunts//
$query = "
INSERT INTO `review_and_rate`(`id`, `rate`, `review`, `parent_email`,`babysitter_email`) VALUES
(1, 5, ' Shes was so good with my kids ', 'DaniaFahad@hotmail.com','MonicaGeller@hotmail.com'),
(2, , 4, ' She is a good person, but she seems exhausted :( ', 'Alkhansaa@hotmail.com', 'MonicaGeller@hotmail.com'),
;"





?>