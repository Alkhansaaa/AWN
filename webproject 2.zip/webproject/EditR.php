<?php
session_start();
if(!isset($_SESSION['Email'])){
  header("Location: ../web.php");
}

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");
if (!$conn = mysqli_connect(host,Username,Password))
    die("Connection failed.");


    if(!mysqli_select_db($conn, db))
        die("Could not open the ".db." database.");

$Kidsname = $_POST['Itemname'];
$numberOfKids = $_POST['number'];
$Duration = $_POST['Duration'];
$date = $_POST['Date'];
$age = $_POST['age'];
$service_name = $_POST['category'];
$parent_email=$_SESSION['Email']['email'];

$query = "UPDATE rquest SET num_of_kids = '$numberOfKids', reqdate='$date',reqstatus='pending', typeofsecvice='$service_name' , kidname='$Kidsname', age='$age' , parent_email='$parent_email', duration='$Duration';";
$result = mysqli_query($conn,$query);

/*
if ($result) {/*
  echo ?><script>
  alert ( edit request successfully)
  </script><?php ;
}
  else {
    echo ?>"<script>
    alert ( there is some error)
    </script>";<?php
  }*/
?>
