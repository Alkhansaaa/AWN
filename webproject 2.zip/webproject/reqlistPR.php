<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION['Email'])){
  header("Location: web.php");
}
?>

<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>My Requests</title>
  <link rel="stylesheet" href="stylereqlistPR.css">
  <link rel="icon" href="icon.png" >


<?php
ini_set('display_errors',1); 
error_reporting(E_ALL);
 

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");


$connection = mysqli_connect(host,Username,Password,db);
if(!$connection){
  print("<p>could not connect to database</p>");
  die("could not connect to the db </html>");

}
$email=$_SESSION['Email'];

$query="SELECT * FROM request where parent_email='$email' AND reqstatus='pending'";



$result=mysqli_query($connection,$query);

if($result){
  echo "yaaaaaaay";
}else{
  echo "naaaay";

}



?>

</head>
<body>
  <header class="cont">
    <nav>
      <a href="ladingP.php"> <h2>AWN</h2> </a>
      <ul class="nav">
        <li><a href="ladingP.php#home">Home</a></li>
        <li><a href="ladingP.php#about">About us</a></li>
        <li><a href="ladingP.php#ser">Servises</a></li>
        <li><a href="ladingP.php#foot">Contact</a>
        </li>
  
       <li><a  class="user" href="logout.php">
           <img src="logout.png" >
           </a>
  
           <div class="dropdown">
            <button class="dropbtn"><img src="profile.png"></button>
            <div class="dropdown-content">
             <a href="ParentProfile.php">Edit profile</a>
             <a href="booking.php">My Booking</a>
   <a href="offerslistPR.php">Offers</a>
   <a href="reqlistPR.php">My Requests</a>
           </div>
         </div>
             
             
           </button>
           </a>
      </li>
     </ul>
   </nav>
      </header>
  
  
<!-- partial:index.partial.html -->
<div class="container">
  <h1>Your requests</h1>
  <hr>

  
  
 <?php 
 
 $counter=1;

 while($row=mysqli_fetch_row($result)){
   ?>
   
   <div class="pop-up animate" id='<?php echo $counter; ?>'><form method="get" action="php/deleterequest.php" id="form1">
   <button class="close " name="delete" value=<?php echo $row[0]; ?> type="submit" form="form1" >
   Delete
   </button></form>
   <button class="edit" type="edit" onclick="window.location.href='index.html'"><strong>Edit</strong></button>


    <div>
    <h2>
      Request <?php echo $counter; ?>
    </h2>
    <hr>

    <h3>
    <?php echo $row[4]?>
    </h3>
    <h3>
    <?php echo $row[2]?>
    </h3>

</div> 
<?php $counter=$counter+1;?>
 </div>
 <?php

}/*
$counter=1;

 while($row=mysqli_fetch_row($result)){
   ?>
   <div class="pop-up animate" id='<?php echo $counter; ?>'>
   <button class="close " onclick="confirmdelete('1')">
   Delete
   </button>
   <button class="edit" type="edit" onclick="window.location.href='index.html'"><strong>Edit</strong></button>


    <div>
    <h2>
      Request <?php echo $counter; ?>
    </h2>
    <hr>

    <h3>
    <?php echo $row[2]?>
    </h3>
    <h3>
    <?php echo $row[3]?>
    </h3>

</div> 
<?php $counter=$counter+1;
}*/
?>
 

</div>
<!-- partial -->
<footer class="footer">
  
  
  <ul class="Lf">
    <li id="foot">
        <a href="ladingP.php#home">Home</a>
    </li>
    <li>
        <a href="ladingP.php#about">About us</a>
    </li>
    <li>
        <a href="ladingP.php#ser">Servises</a>
    </li>
    <li>
        <a href="ladingP.php#foot">Contact</a>
    </li>
      
  </ul>
  
          <ul class="icon">
              <li>
                  <a href="">
                      <img src="twitter.png">
                  </a>
              </li>
              <li>
                  <a href="#">
                      <img src="linkedin.png">
                  </a>
              </li>
              <li>
                  <a href="">
                      <img src="instagram.png">
                  </a>
              </li>  
                   

  <p class="copyRight">
     AWN'S team &#169; 2021
      </p>
    </footer>
    
    <script>
  function confirmdelete(x){
   var result= confirm("are you sure you want to delete the request?");
   if(result){
    const element = document.getElementById(x);
    element.remove();
    
    
   }

  }
</script>
</body>


</html>

<!--onclick=confirmdelete(<?php /*echo $counter; */?>)-->