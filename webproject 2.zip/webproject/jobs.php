<!DOCTYPE html>
<?php
if(!isset($_SESSION['EmailB']))
        // header() is used to send a raw HTTP header. It must be called before any actual output is sent.
        header("Location: web.php");
        ?>
<html lang="en" id="booking">
<head>
  <meta charset="UTF-8">
  <title>Jobs</title>
  <link rel="stylesheet" href="jobsstyle.css">
  <link rel="icon" href="icon.png" >
  <?php
  ini_set('display_errors',1); 
  error_reporting(E_ALL);
  
   Define("host","localhost");
   Define("Username", "root");
   Define("Password", "");
   Define("db", "AWN'S");
  
  
  
   $connection = mysqli_connect(host,Username,Password,db);
   if(!$connection){
     print("<p>could not connect to database</p>");
     die("could not connect to the db </html>");
   
   }
   $email=$_SESSION['EmailB'];
   $query="SELECT * FROM bookingandjobs WHERE babysitter_email='$email'";
   
   
   
   $result=mysqli_query($connection,$query);
   
   if($result){
     echo "yaaaaaaay";
   }else{
     echo "naaaay";
   
   }
  
  
  
?>  

</head>
<body>
  <header class="cont">
  
    <nav>
      <a href="babys.php"> <h2>AWN</h2> </a>
      <ul class="nav">
        <li><a href="babys.php">Home</a></li>
        <li><a href="babys.php#about">About us</a></li>
        <li><a href="babys.php#ser">Servises</a></li>
        <li><a href="babys.php#foot">Contact</a>
        </li>
   
  
        <li><a  class="user" href="logout.php">
            <img src="logout.png" >
            </a>
  
            <div class="dropdown">
              <button class="dropbtn"><img src="profile.png"></button>
              <div class="dropdown-content">
                  <a href="babysitter.php">Edit profile</a>
                <a href="jobs.php">jobs</a>
                <a href="offerslistBS.php">My Offers</a>
              </div>
            </div>
              
              
            </button>
            </a>
       </li>
      </ul>
    </nav>
      </header>
  
  
<!-- partial:index.partial.html -->
<div class="Current">
<h1 class="title">Current Jobs</h1>

<div class="slider" x-data="{start: true, end: false}">
  <div class="slider__content" x-ref="slider" x-on:scroll.debounce="$refs.slider.scrollLeft == 0 ? start = true : start = false; Math.abs(($refs.slider.scrollWidth - $refs.slider.offsetWidth) - $refs.slider.scrollLeft) < 5 ? end = true : end = false;">
    
    
    
    
  
<?php
while($row=mysqli_fetch_row($result)){ 
   $query2="SELECT * FROM request WHERE request_id='$row[1]'AND reqdate>=(CAST(CURRENT_TIMESTAMP AS DATE))";
    $result2=mysqli_query($connection,$query2);
    while($row2=mysqli_fetch_row($result2)){  
   ?>
<div class="slider__item">
    <h2><?php echo $row2[4]?></h2>
    <div class="cslider__info">
      <h3><a href="#"><?php echo $row[2]?></a></h3>
     
      <h3>Duration:<?php echo $row2[8]?> Hours</h3>
      <h3><?php echo $row[1]?></h3></div>
</div>
<?php } } ?>


    
    
    
    
    
    
    </div>
  </div>
  <div class="slider__nav">
    <button class="slider__nav__button" x-on:click="$refs.slider.scrollBy({left: $refs.slider.offsetWidth * -1, behavior: 'smooth'});" x-bind:class="start ? '' : 'slider__nav__button--active'">Previous</button>
    <button class="slider__nav__button" x-on:click="$refs.slider.scrollBy({left: $refs.slider.offsetWidth, behavior: 'smooth'});" x-bind:class="end ? '' : 'slider__nav__button--active'">Next</button>
  </div>
</div>
<hr>

<div class="Previous">
    <h1 class="title">Previous Jobs</h1>
    
    <div class="slider" x-data="{start: true, end: false}">
      <div class="slider__content" x-ref="slider" x-on:scroll.debounce="$refs.slider.scrollLeft == 0 ? start = true : start = false; Math.abs(($refs.slider.scrollWidth - $refs.slider.offsetWidth) - $refs.slider.scrollLeft) < 5 ? end = true : end = false;">
        
        
        
        <?php 
        
         $query4="SELECT * FROM bookingandjobs WHERE babysitter_email='joey@gmail.com'";
         
         
         


$result4=mysqli_query($connection,$query4);
    
while($row4=mysqli_fetch_row($result4)){ 
    
   $query3="SELECT * FROM request WHERE request_id='$row[1]'AND reqdate<(CAST(CURRENT_TIMESTAMP AS DATE))";
    $result3=mysqli_query($connection,$query3);
   
  while($row3=mysqli_fetch_row($result3)){
    
    ?>
<div class="slider__item">
    <h2><?php echo $row3[4]?></h2>
    <div class="cslider__info">
      <h3><a href="#"><?php echo $row[2]?></a></h3>
     
      <h3>Duration:<?php echo $row3[8]?> Hours</h3>
      <h3><?php echo $row3[1]?></h3></div>
</div>
<?php }} ?>






      </div>
      <div class="slider__nav">
        <button class="slider__nav__button" x-on:click="$refs.slider.scrollBy({left: $refs.slider.offsetWidth * -1, behavior: 'smooth'});" x-bind:class="start ? '' : 'slider__nav__button--active'">Previous</button>
        <button class="slider__nav__button" x-on:click="$refs.slider.scrollBy({left: $refs.slider.offsetWidth, behavior: 'smooth'});" x-bind:class="end ? '' : 'slider__nav__button--active'">Next</button>
      </div>
    </div>
</div>
<!-- partial -->
<footer class="footer">
  
  
  <ul class="Lf">
    <li id="foot">
        <a href="babys.html#home">Home</a>
    </li>
    <li>
        <a href="babys.html#about">About us</a>
    </li>
    <li>
        <a href="babys.html#ser">Servises</a>
    </li>
    <li>
        <a href="babys.html#foot">Contact</a>
    </li>
      
  </ul>
      
  </ul>
  
          <ul class="icon">
              <li>
                  <a href="">
                      <img src="twitter.png">
                  </a>
              </li>
              <li>
                  <a href="#">
                      <img src="linkedin.png">
                  </a>
              </li>
              <li>
                  <a href="">
                      <img src="instagram.png">
                  </a>
              </li>  
                   

  <p class="copyRight">
     AWN's team &#169; 2021
      </p>
    </footer>

</body>
</html>
