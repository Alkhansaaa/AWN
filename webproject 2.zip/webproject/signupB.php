<?php
    if (isset($_POST['submit1']))
    {

Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN'S");


    if (!$conn = mysqli_connect(host,Username,Password))
        die("Connection failed.");


        if(!mysqli_select_db($conn, db))
            die("Could not open the ".db." database.");



            $First_Name = $_POST['fname'];
            $Last_Name = $_POST['lname'];
            $Email = $_POST['Email'];
            $id= $_POST['ID'];
            $phone=$_POST['phone'];
            $Password = $_POST['Password'];
            $cPassword = $_POST['Password1'];
            $age=$_POST['age'];
            $gender=$_POST['gender'];
            $bio=$_POST['Bio'];
            $city=$_POST['city'];

            $errorB=[];

            //if($_FILES['img']['size'] > 0){
              //$img = $_FILES['profile-img']['tmp_name'];
            //  $img = addslashes(file_get_contents($img));
            //}
            //else{
            //  $img = null;
            //}
            $validateEmail = preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $Email);
            $specialChars = preg_match('@[^\w]@', $Password);
            //$validatephone = preg_match("/^([0-9\[10]", $phone);


            if(strlen($First_Name) < 3 || (strlen($First_Name) >20))
            {
            $errorB[]="Name must be between 3 and 20";
            //header("Location: ../signUpB1.php");
            //$_SESSION['Sign_up_error'] ="Name must be between 3 and 20";
            }



            if(strlen($age) < 23 ||(strlen($age) > 40 ))
            {
            $errorB[]="Age must be between 23 and 40";
            //header("Location: ../signUpB1.php");
            }

            //if(!$validatephone)
            //{
            //$errorB[]="invalid phone number";
            //header("Location: ../signUpB1.php");
            //$_SESSION['Sign_up_error'] ="Name must be between 3 and 20";
            //}

            if(filter_var($phone, FILTER_VALIDATE_INT)==false ||strlen($phone)<9||strlen($phone)>9){
                $errorB[]=" Phone number must be 10 digits"; }



            if(!$validateEmail){
              $errorB[]="Invalid email address.";

            }

            if( !$specialChars && strlen($Password) < 8) {
            $errorB[]="Password must be at least 8 characters and contain at least one special character #,&,..";

            }
            if(strlen($Password) < 8){
            $errorB[]="Password should be at leat 8 characters";

            }

            if($cPassword != $Password)
            {
            $errorB[]="Password does not match";

            }



            if( !$specialChars ) {
            $errorB[]="Password must contain at least one special character #,&,..";

            }

            //check if the email exits
            $queryID= "SELECT * FROM babysitter WHERE id = '$id' ";
            $babysitterResultt = mysqli_query($conn,$queryID);
            if (mysqli_num_rows( $babysitterResultt)>0)
            {
            $errorB[]="Id exists!";

              $conn -> close();
              //exit;
            }




            $query = "SELECT * FROM babysitter WHERE Email = '$Email' ";
            $babysitterResult = mysqli_query($conn,$query);

            if (mysqli_num_rows( $babysitterResult)>0)
            {
            $errorB[]="Email exists!";
              //$_SESSION['Sign_up_error'] = 'Email exists!';
              //header("Location: ../signUpB1.php");
              $conn -> close();
              //exit;
            }

            //if($img == null)
            //$query="INSERT INTO `babysitter` VALUES ('$First_Name','$Last_Name','$Password','$city','#id','$gender','age','$Email','$phone','#city','$bio', NULL)";
            //else
            //INSERT INTO `babysitter`(`password`, `id`, `gender`, `age`, `email`, `phone_number`, `city`, `bio`, `profile_photo`, `firstname`, `lastname`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]','[value-8]','[value-9]','[value-10]','[value-11]')
            $query="INSERT INTO `babysitter` (`password`, `id`, `gender`, `age`, `email`, `phone_number`, `city`, `bio`, `profile_photo`, `firstname`, `lastname`) VALUES ('$Password','$id','$gender','$age','$Email','$phone','$city','$bio',null,'$First_Name','$Last_Name')";
            if (mysqli_query($conn, $query)) {
              //echo "<script>
              //alert(
                //"New record created successfully !"
              //  )
              //</script>";
              $_SESSION['EmailB'] = $Email ; //!sure if email
              header("Location: babys.php");
              $con -> close();
              exit;
            } else {
              echo "Error: ".mysqli_error($conn);
            }
            }






            ?>
