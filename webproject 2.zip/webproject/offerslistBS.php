<!DOCTYPE html>
<?php
session_start();


        ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offers</title>
    <link rel="stylesheet" href="offerslistBSstyle.css">
    <link rel="icon" href="icon.png" >

    <?php
ini_set('display_errors',1); 
error_reporting(E_ALL);

 Define("host","localhost");
 Define("Username", "root");
 Define("Password", "");
 Define("db", "AWN'S");



 $connection = mysqli_connect(host,Username,Password,db);
 if(!$connection){
   print("<p>could not connect to database</p>");
   die("could not connect to the db </html>");
 
 }
 $email=$_SESSION['EmailB'];
 
 $query="SELECT * FROM offers WHERE babysitter_email='$email'";
 
 
 
 $result=mysqli_query($connection,$query);
 
 if($result){
   echo "yaaaaaaay";
 }else{
   echo "naaaay";
 
 }





?>

</head>
<body>

    <header class="cont">
  
        <nav>
            <a href="babys.php"> <h2>AWN</h2> </a>
            <ul class="nav">
                <li><a href="babys.php">Home</a></li>
                <li><a href="babys.php#about">About us</a></li>
                <li><a href="babys.php#ser">Servises</a></li>
                <li><a href="babys.php#foot">Contact</a>
                </li>
      
            <li><a  class="user" href="logout.php">
                <img src="logout.png" >
                </a>
      
                <div class="dropdown">
              <button class="dropbtn"><img src="profile.png"></button>
              <div class="dropdown-content">
                  <a href="babysitter.php">Edit profile</a>
                <a href="jobs.php">jobs</a>
                <a href="offerslistBS.php">My Offers</a>
              </div>
            </div>
                  
                  
                  
                </button>
                </a>
           </li>
          </ul>
        </nav>
          </header>
      
      
   
   <div class="main">
    
        <div class="cards">
                <h1>Your offers</h1>
    
                <div class="cards1" >
    
                

             <?php
                            
                            
                while($row=mysqli_fetch_row($result)){ ?>
                    <div class="popup"><img src="<?php 
                    if($row[5]=='accepted')
                    echo 'images/accepted.png';
                    if($row[5]=='rejected')
                    echo 'images/rejected.png';
                    if($row[5]=='pending')
                    echo 'images/expired.png';?>
                    "><h2 class="Expired"><?php 
                    if($row[5]=='accepted')
                    echo 'Accepted';
                    if($row[5]=='rejected')
                    echo 'Rejected';
                    if($row[5]=='pending')
                    echo 'Pending';?>
                    </h2>
                    <hr>
                    <div class="info">
    
                        <h3><?php echo $row[1]?> SAR</h3>
                       
                        
                        <h4> <a href="profile.php"><?php echo $row[3]?></a></h4>
                    </div>
                </div>

                <?php
                }

                ?>
                                
    
                               
                                
                            
                     
            </div>
       
        </div>
</div>
    
<footer class="footer">
  
  
    <ul class="Lf">
        <li id="foot">
            <a href="babys.php#home">Home</a>
        </li>
        <li>
            <a href="babys.php#about">About us</a>
        </li>
        <li>
            <a href="babys.php#ser">Servises</a>
        </li>
        <li>
            <a href="babys.php#foot">Contact</a>
        </li>
        
    </ul>
    
            <ul class="icon">
                <li>
                    <a href="">
                        <img src="twitter.png">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="linkedin.png">
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="instagram.png">
                    </a>
                </li>  
                     
  
    <p class="copyRight">
       AWN'S team &#169; 2021
        </p>
      </footer>

</body>
</html>