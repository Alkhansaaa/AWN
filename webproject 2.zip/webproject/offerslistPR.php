<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION['Email'])){
  header("Location: web.php");
}
?>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Offers</title>
  <link rel="stylesheet" href="offerslistPR.css">
  <link rel="icon" href="icon.png" >
  <?php
ini_set('display_errors',1); 
error_reporting(E_ALL);

 Define("host","localhost");
 Define("Username", "root");
 Define("Password", "");
 Define("db", "AWN'S");



 $connection = mysqli_connect(host,Username,Password,db);
 if(!$connection){
   print("<p>could not connect to database</p>");
   die("could not connect to the db </html>");
 
 }
 $email=$_SESSION['Email'];
 $query="SELECT * FROM offers WHERE parent_email='$email' AND offerstatus='pending'";
 
 
 
 $result=mysqli_query($connection,$query);
 




  ?>


</head>
<body>
<!-- partial:index.partial.html -->
<header class="cont">
        
  <nav>
    <a href="ladingP.php"> <h2>AWN</h2> </a>
    <ul class="nav">
      <li><a href="ladingP.php#home">Home</a></li>
      <li><a href="ladingP.php#about">About us</a></li>
      <li><a href="ladingP.php#ser">Servises</a></li>
      <li><a href="ladingP.php#foot">Contact</a>
      </li>

     <li><a  class="user" href="logout.php">
         <img src="logout.png" >
         </a>

         <div class="dropdown">
             <button class="dropbtn"><img src="profile.png"></button>
             <div class="dropdown-content">
              <a href="profiles.php">Edit profile</a>
              <a href="booking.php">My Booking</a>
    <a href="offerslistPR.phpl">Offers</a>
    <a href="reqlistPR.php">My Requests</a>
            </div>
          </div>
           
           
         </button>
         </a>
    </li>
   </ul>
 </nav>
<hr>


</header>

<div class="container">
  <h1>Offers</h1>
  <hr id="title">

  
  
  
  
  
  


  <?php
  $counter=1;

   while($row=mysqli_fetch_row($result)){ 
    
    $query1="SELECT reqdate FROM request WHERE request_id='$row[4]'";
    $requestdate=mysqli_query($connection,$query1);
    date_default_timezone_set('UTC');
    if($requestdate==date("Y-m-d")){
      

     $query2="DELETE FROM offers WHERE request_id='$row[4]'";//delete forgion key from offer
      $result2= mysqli_query($connection,$query2);
      
      $deleterequestquery="DELETE FROM request WHERE request_id='$row[4]'";//delete the request
      $resultdelete= mysqli_query($connection,$deleterequestquery);

    }else{

    ?>
   <div class="pop-up animate" id='<?php echo $counter; ?>'>
   <form action="php/accept_offer.php" method="get" id="form1">
   <button class="close four" form="form1" type="submit" name="reject" value="<?php echo $row[0]; ?>" >
      <strong>Reject</strong>
    </button>
   
    <button class="accept" form="form1" type="submit" name="accept" value="<?php echo $row[0];?>"><strong>Accept</strong></button>
    
   <div>
      <h2>
        <a href="#"><?php echo $row[3]; ?></a>
      </h2>
      <h3>
        type of service <h4>#request number</h4> 
      </h3>
      
      <hr>
      <h3 class="offer1">
      <?php echo $row[1] ;?>
      </h3>
      <h3 class="offer">
        OFFER 
        <h3 class="currancy">
         SAR        
          </h3>
      </h3>

  </div>
  </div>
  <?php $counter=$counter+1;?>
<?php
   }}?>




   



   

  






  
 
  
</div>
<!-- partial -->


<footer class="footer">
    
    <ul class="Lf">
      <li id="foot">
          <a href="ladingP.php#home">Home</a>
      </li>
      <li>
          <a href="ladingP.php#about">About us</a>
      </li>
      <li>
          <a href="ladingP.php#ser">Servises</a>
      </li>
      <li>
          <a href="ladingP.php#foot">Contact</a>
      </li>
        
    </ul>
    
            <ul class="icon">
                <li>
                    <a href="">
                        <img src="twitter.png">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="linkedin.png">
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="instagram.png">
                    </a>
                </li>  
                      

    <p class="copyRight">
       AWN'S team &#169; 2021
        </p>

      </footer>

      <script>
        

        </script>

</body>
</html>
