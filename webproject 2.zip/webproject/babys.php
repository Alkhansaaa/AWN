<!DOCTYPE html>
<?php
    session_start();
    // Check if the user has already logged in
    if(!isset($_SESSION['EmailB']))
        // header() is used to send a raw HTTP header. It must be called before any actual output is sent.
        header("Location: web.php");

        ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AWN</title>
    <link rel="stylesheet" href="weeb.css" >
    <link rel="icon" href="icon.png" >
</head>
<body>
    <section class="cont">
        <nav id="home">
            <img src="logo.svg">
          <ul class="nav">
            <li><a href="#content">Home</a></li>
            <li><a href="#about">About us</a></li>
            <li><a href="#ser">Servises</a></li>
            <li><a href="#foot">Contact</a>
                <li><a href="requestlistBS.php">Explore</a>
            </li>

            <li><a  class="user" href="logout.php">
                <img src="logout.png" >
                </a>

                <div class="dropdown">
                    <button class="dropbtn"><img src="profile.png"></button>
                    <div class="dropdown-content">
                        <a href="BabyProfile.php">Edit profile</a>
                      <a href="jobs.php">jobs</a>
                      <a href="offerslistBS.php">My Offers</a>
                    </div>
                  </div>


                </button>
                </a>
           </li>
          </ul>
        </nav>

        <div class="content">

            <div class="text">
                <br><br>
                <h1 > Welcome back babysitter!</h1>
                <p>AWN made it easy for you to connect with parents, make offers, and find the perfect job..</p>
                     <a href="requestlistBS.php" id="joun"class="sign">Look for a job</a>

            </div>






    </section>

    <!--new section about us -->
        <section class="about">

            <div class="content1">
                <h1 id="about">
                    about us
                </h1>
                <p>The demands of today’s parents continue to increase every year.
                    We created this platform to connect parents with childcare professionals, and we simplified this connection,
                     which will make it easy for you and the babysitter to get in touch and have the best offers.</p>
                </p>

            </div>
        </section>


        <!-- Servises-->

        <section class="servise" >
            <div class="heading">
                <h2 id="ser">what AWN's helps you to do </h2>



            <div class="servise-container">

                <div class="row">
                    <img src="userr.png"><br>
                    <h3> Find a jobr</h3>

                    </div>


                        <div class="row">
                            <img src="question-mark.png"><br>
                            <h3> Create an offer </h3>

                            </div>


                                <div class="row">
                                    <img src="knowledge.png"><br>
                                    <h3> Make a money </h3>

                                    </div>




            </div>
            <br>
            <br>

        </section>

        <!-- footer-->
        <section class="footer">

        <ul class="Lf">
            <li id="foot">
                <a href="#home">Home</a>
            </li>
            <li>
                <a href="#about">About us</a>
            </li>
            <li>
                <a href="#ser">Servises</a>
            </li>
            <li>
                <a href="#foot">Contact</a>
            </li>

        </ul>





                <ul class="icon">
                    <li>
                        <a href="">
                            <img src="twitter.png">
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <img src="linkedin.png">
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <img src="instagram.png">
                        </a>
                    </li>








        <p class="copyRight">
           AWN'S team &#169; 2021
            </p>





        </section>



</body>
</html>
