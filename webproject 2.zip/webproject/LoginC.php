<?php

    if (isset($_POST['submitt']))
{
    Define("host","localhost");
    Define("Username", "root");
    Define("Password", "");
    Define("db", "AWN'S");

    $errorL=[];


        if (!$conn = mysqli_connect(host,Username,Password))
            die("Connection failed.");


            if(!mysqli_select_db($conn, db))
                die("Could not open the ".db." database.");

    $Email = $_POST['email'];
    $Password = $_POST['password'];

    $queryP = "SELECT * FROM parent WHERE email = '$Email' AND  password ='$Password'";
    $resultP = mysqli_query($conn,$queryP);

    $queryB = "SELECT * FROM babysitter WHERE email = '$Email' AND password = '$Password'";
    $resultB = mysqli_query($conn,$queryB);

    if(mysqli_num_rows($resultP) > 0){
        $_SESSION['Email'] = $Email;
        $conn -> close();
        header("Location: ladingP.php");
        //echo "<sript>
        //alert(loged in)
        //</script>";
    }
    else if(mysqli_num_rows($resultB) > 0){
        $_SESSION['EmailB'] = $Email;
        $conn -> close();
        header("Location: babys.php");
    }
    else {
        $conn -> close();
        $errorL[]="Incorrect Email or password";
        echo "Error: ".mysqli_error($conn);

        //header("Location: ../logIn.php?error=Incorrect Email or password");
    }
  }
?>
