<?php

$email = $_SESSION['email'];


Define("host","localhost");
Define("Username", "root");
Define("Password", "");
Define("db", "AWN_S");


    if (!$conn = mysqli_connect(host,Username,Password))
        die("Connection failed.");


        if(!mysqli_select_db($conn, db))
            die("Could not open the ".db." database.");

            $query = "SELECT * FROM Request WHERE  (Status = 'pending') //date >" ;
            $result = mysqli_query($conn, $query);
            if($result){
            if (mysqli_num_rows($result)>0)
