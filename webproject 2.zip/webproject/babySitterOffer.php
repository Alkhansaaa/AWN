<!DOCTYPE html>
<?php

ini_set('display_errors',1); 
error_reporting(E_ALL);

session_start();

if(isset($_SESSION['premail'])){
  $parentemail=$_SESSION['premail'];
  echo $_SESSION['premail']."yaaay";
  


        
/*

$email = $_SESSION['emailB'];
*/


?>
<html>
  
  <head>
    <meta charset="UTF-8">
    <title> send offer </title>
    <link rel="stylesheet" href="parentaRequest.css">
    <link rel="icon" href="icon.png" >



    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="babyaSitterOffer" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<?php 

ini_set('display_errors',1); 
error_reporting(E_ALL);

?>

  <section class="cont">
      <nav>
        <a href="babys.php"> <h2>AWN</h2> </a>
        <ul class="nav">
            <li><a href="babys.php">Home</a></li>
            <li><a href="babys.php#about">About us</a></li>
            <li><a href="babys.php#ser">Servises</a></li>
            <li><a href="babys.php#foot">Contact</a>
            </li>

        <li><a  class="user" href="logout.php">
            <img src="logout.png" >
            </a>

            <div class="dropdown">
              <button class="dropbtn"><img src="profile.png"></button>
              <div class="dropdown-content">
                  <a href="babysitter.php">Edit profile</a>
                <a href="jobs.php">jobs</a>
                <a href="offerslistBS.html">My Offers</a>
              </div>
            </div>


            </button>
            </a>
       </li>
      </ul>
    </nav>
  </section>

<div class="container">
      <h2>create an offer </h2>



   <div class="row">
      <div class="col-75">
        <form action="php/addoffer.php" method= "get" id="form1">
        <label for="Price">Offer</label>
        <input type="text" id="Price" name="Price" name="price" placeholder="Price..">
        <button form="form1" name="parentemaill" value="<?php echo $parentemail; ?>"></button>
        
        </div>


      <br>
      <label for="currancy">currancy</label>
      <br>
      <label for="SAR">SAR</label>


    </div>

    <div class ="row">

     <br>

      <input type="Submit" value="send offer" id="form1">
      <br>
      <br>

    </div>



</div>

<?php } ?>

<footer>
  <section class="footer">

    <ul class="Lf">
      <li id="foot">
          <a href="babys.php#home">Home</a>
      </li>
      <li>
          <a href="babys.php#about">About us</a>
      </li>
      <li>
          <a href="babys.php#ser">Servises</a>
      </li>
      <li>
          <a href="babys.php#foot">Contact</a>
      </li>

    </ul>

            <ul class="icon">
                <li>
                    <a href="">
                        <img src="twitter.png">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="linkedin.png">
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="instagram.png">
                    </a>
                </li>


    <p class="copyRight">
       AWN'S team &#169; 2021
        </p>
      </footer>
    </section>
</body>
</html>
